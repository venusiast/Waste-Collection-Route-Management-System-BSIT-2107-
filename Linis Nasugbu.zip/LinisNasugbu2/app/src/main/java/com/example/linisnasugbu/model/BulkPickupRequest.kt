package com.example.linisnasugbu.model

import com.example.linisnasugbu.model.enums.RequestStatus
import java.time.LocalDate

data class BulkPickupRequest(
    val requestId: String,
    val residentId: String,
    val location: Location,
    val dateRequested: LocalDate,
    val preferredDate: LocalDate,
    val wasteDescription: String,
    val estimatedVolume: String,
    var status: RequestStatus = RequestStatus.PENDING,
    val notes: String = ""
)
