package com.example.linisnasugbu.model

data class Location(
    val fullAddress: String,
    val barangay: String,
    val zone: String,
    val latitude: Double? = null,
    val longitude: Double? = null
)
