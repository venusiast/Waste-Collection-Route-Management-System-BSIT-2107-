package com.example.linisnasugbu.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import com.example.linisnasugbu.ui.theme.BackgroundLight
import com.example.linisnasugbu.ui.theme.CoastalNavy
import com.example.linisnasugbu.ui.theme.EcoGreen
import com.example.linisnasugbu.ui.theme.SafetyOrange
import com.example.linisnasugbu.ui.theme.SurfaceWhite
import com.example.linisnasugbu.ui.theme.TextPrimary

private val LightColorScheme = lightColorScheme(
    primary = CoastalNavy,
    secondary = EcoGreen,
    tertiary = SafetyOrange,
    background = BackgroundLight,
    surface = SurfaceWhite,
    onPrimary = SurfaceWhite,
    onSecondary = SurfaceWhite,
    onBackground = TextPrimary,
    onSurface = TextPrimary
)

@Composable
fun NasugbuWasteTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = LightColorScheme,
        typography = Typography, // Galing sa Type.kt mo
        content = content
    )
}