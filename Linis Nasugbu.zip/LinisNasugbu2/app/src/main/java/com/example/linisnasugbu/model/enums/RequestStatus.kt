package com.example.linisnasugbu.model.enums

enum class RequestStatus {
    PENDING,
    APPROVED,
    SCHEDULED,
    COMPLETED,
    CANCELLED
}
