package com.example.linisnasugbu.ui.theme

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.linisnasugbu.R

@Composable
fun LoginScreen(onLoginSuccess: (role: String, userName: String) -> Unit) {
    var credential by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    // Automatic Role Detection base sa Account / ID (walang manual role chips)
    fun authenticateAndRoute(input: String) {
        val cleanInput = input.trim().lowercase()
        when {
            cleanInput.isBlank() -> {
                errorMessage = "Please enter your email or municipal ID."
            }
            cleanInput.contains("manager") || cleanInput.contains("admin") || cleanInput.startsWith("mgr-") -> {
                errorMessage = null
                onLoginSuccess("Manager", "Engr. Maria Santos")
            }
            cleanInput.contains("collector") || cleanInput.contains("driver") || cleanInput.startsWith("col-") -> {
                errorMessage = null
                onLoginSuccess("Collector", "Kuya Pedro Reyes")
            }
            else -> {
                errorMessage = null
                // Kunin ang unang bahagi ng email bilang pangalan kung walang nakalagay
                val displayName = if (cleanInput.contains("@")) {
                    cleanInput.substringBefore("@").replaceFirstChar { it.uppercase() }
                } else {
                    "Juan Dela Cruz"
                }
                onLoginSuccess("Resident", displayName)
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundLight)
    ) {
        // 1. Top Gradient Brand Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(270.dp)
                .clip(RoundedCornerShape(bottomStart = 36.dp, bottomEnd = 36.dp))
                .background(NasugbuHeroGradient),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(bottom = 28.dp)
            ) {
                Surface(
                    shape = CircleShape,
                    color = SurfaceWhite,
                    shadowElevation = 6.dp,
                    modifier = Modifier.size(86.dp)
                ) {
                    Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(10.dp)) {
                        Image(
                            painter = painterResource(id = R.drawable.ic_launcher_foreground),
                            contentDescription = "LinisNasugbu Logo",
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "LinisNasugbu",
                    color = SurfaceWhite,
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = (-0.5).sp
                )
                Text(
                    text = "Smart Waste & Route Management • Batangas",
                    color = SurfaceWhite.copy(alpha = 0.85f),
                    fontSize = 12.sp
                )
            }
        }

        // 2. Floating Login Card
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp)
                .padding(top = 215.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(24.dp)) {
                    Text(
                        text = "Welcome Back",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "Sign in with your Resident email or LGU Staff ID",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    OutlinedTextField(
                        value = credential,
                        onValueChange = {
                            credential = it
                            errorMessage = null
                        },
                        label = { Text("Email or Staff ID") },
                        placeholder = { Text("e.g. juan@email.com or COL-04") },
                        leadingIcon = {
                            Icon(Icons.Default.Email, contentDescription = null, tint = CoastalTeal)
                        },
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("Password") },
                        leadingIcon = {
                            Icon(Icons.Default.Lock, contentDescription = null, tint = CoastalTeal)
                        },
                        visualTransformation = PasswordVisualTransformation(),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    if (errorMessage != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = errorMessage!!,
                            color = AlertRed,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    Spacer(modifier = Modifier.height(22.dp))

                    Button(
                        onClick = { authenticateAndRoute(credential) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = EcoGreen),
                        elevation = ButtonDefaults.buttonElevation(4.dp)
                    ) {
                        Text(
                            text = "Continue",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = SurfaceWhite
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // 3. Discreet One-Tap Demo Helper (Para madaling i-test sa defense)
            Text(
                text = "Quick Demo Access (Tap to auto-fill):",
                fontSize = 11.sp,
                color = TextSecondary
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                DemoAccountChip("Resident", Modifier.weight(1f)) {
                    credential = "juan.wawa@nasugbu.ph"
                    password = "••••••••"
                }
                DemoAccountChip("Collector", Modifier.weight(1f)) {
                    credential = "COL-04@nasugbu.gov.ph"
                    password = "••••••••"
                }
                DemoAccountChip("Manager", Modifier.weight(1f)) {
                    credential = "MGR-santos@nasugbu.gov.ph"
                    password = "••••••••"
                }
            }
        }
    }
}

@Composable
private fun DemoAccountChip(label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = SurfaceWhite,
        border = androidx.compose.foundation.BorderStroke(1.dp, BorderLight),
        modifier = modifier.clickable { onClick() }
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.padding(vertical = 8.dp)
        ) {
            Text(
                text = label,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = CoastalTeal
            )
        }
    }
}