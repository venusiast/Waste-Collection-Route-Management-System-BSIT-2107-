package com.example.linisnasugbu.ui.theme

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.linisnasugbu.R
import com.example.linisnasugbu.service.LinisNasugbuRepository

@Composable
fun LoginScreen(onLoginSuccess: (role: String, userName: String) -> Unit) {
    var isSignUpMode by remember { mutableStateOf(false) }
    var fullName by remember { mutableStateOf("") }
    var credential by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    fun handleAuthSubmit() {
        val cleanInput = credential.trim().lowercase()
        if (isSignUpMode) {
            if (fullName.isBlank()) {
                errorMessage = "Please enter your full name."
                return
            }
            if (cleanInput.isBlank() || !cleanInput.contains("@")) {
                errorMessage = "Please enter a valid email address."
                return
            }
            if (password.length < 4) {
                errorMessage = "Password must be at least 4 characters."
                return
            }
            errorMessage = null
            LinisNasugbuRepository.registerResidentAccount(fullName, cleanInput, password)
            LinisNasugbuRepository.userEmail = cleanInput
            onLoginSuccess("Resident", fullName.trim())
            return
        }

        // Sign In Mode: Automatic Role Routing
        when {
            cleanInput.isBlank() -> {
                errorMessage = "Please enter your email or municipal ID."
            }
            password.isBlank() -> {
                errorMessage = "Please enter your password."
            }
            cleanInput.contains("manager") || cleanInput.contains("admin") || cleanInput.startsWith("mgr-") -> {
                errorMessage = null
                onLoginSuccess("Manager", "Engr. Maria Santos")
            }
            cleanInput.contains("collector") || cleanInput.contains("driver") || cleanInput.startsWith("col-") -> {
                errorMessage = null
                onLoginSuccess("Collector", "Kuya Pedro Reyes")
            }
            else -> {
                errorMessage = null
                var matchedName = ""
                for (acc in LinisNasugbuRepository.registeredAccounts) {
                    if (acc.email == cleanInput) {
                        matchedName = acc.fullName
                        break
                    }
                }
                val displayName = if (matchedName.isNotEmpty()) {
                    matchedName
                } else if (cleanInput.contains("@")) {
                    val rawName = cleanInput.substringBefore("@")
                    rawName.substring(0, 1).uppercase() + rawName.substring(1)
                } else {
                    "Juan Dela Cruz"
                }
                LinisNasugbuRepository.userEmail = cleanInput
                onLoginSuccess("Resident", displayName)
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundLight)
            .verticalScroll(rememberScrollState())
    ) {
        // 1. Top Gradient Brand Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(265.dp)
                .clip(RoundedCornerShape(bottomStart = 36.dp, bottomEnd = 36.dp))
                .background(NasugbuHeroGradient),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(bottom = 28.dp)
            ) {
                Surface(
                    shape = CircleShape,
                    color = SurfaceWhite,
                    shadowElevation = 6.dp,
                    modifier = Modifier.size(84.dp)
                ) {
                    Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(10.dp)) {
                        Image(
                            painter = painterResource(id = R.drawable.ic_launcher_foreground),
                            contentDescription = "LinisNasugbu Logo",
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "LinisNasugbu",
                    color = SurfaceWhite,
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = (-0.5).sp
                )
                Text(
                    text = "Smart Waste & Route Management • Batangas",
                    color = SurfaceWhite.copy(alpha = 0.85f),
                    fontSize = 12.sp
                )
            }
        }

        // 2. Floating Login / Sign Up Card
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
                .padding(top = 210.dp, bottom = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(24.dp)) {
                    Text(
                        text = if (isSignUpMode) "Create Resident Account" else "Welcome Back",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = if (isSignUpMode)
                            "Register to track collection trucks & submit requests"
                        else
                            "Sign in with your Resident email or LGU Staff ID",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    if (isSignUpMode) {
                        OutlinedTextField(
                            value = fullName,
                            onValueChange = { fullName = it; errorMessage = null },
                            label = { Text("Full Name") },
                            placeholder = { Text("e.g. Juan Dela Cruz") },
                            leadingIcon = {
                                Icon(Icons.Default.Person, contentDescription = null, tint = CoastalTeal)
                            },
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                    }

                    OutlinedTextField(
                        value = credential,
                        onValueChange = {
                            credential = it
                            errorMessage = null
                        },
                        label = { Text(if (isSignUpMode) "Email Address" else "Email or Staff ID") },
                        placeholder = { Text("e.g. juan@email.com") },
                        leadingIcon = {
                            Icon(Icons.Default.Email, contentDescription = null, tint = CoastalTeal)
                        },
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it; errorMessage = null },
                        label = { Text("Password") },
                        leadingIcon = {
                            Icon(Icons.Default.Lock, contentDescription = null, tint = CoastalTeal)
                        },
                        visualTransformation = PasswordVisualTransformation(),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    if (errorMessage != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = errorMessage!!,
                            color = AlertRed,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    Button(
                        onClick = { handleAuthSubmit() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = EcoGreen),
                        elevation = ButtonDefaults.buttonElevation(4.dp)
                    ) {
                        Text(
                            text = if (isSignUpMode) "Sign Up & Continue" else "Sign In",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = SurfaceWhite
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    TextButton(
                        onClick = {
                            isSignUpMode = !isSignUpMode
                            errorMessage = null
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = if (isSignUpMode)
                                "Already have an account? Sign In"
                            else
                                "Don't have an account? Sign Up",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = CoastalTeal
                        )
                    }
                }
            }

            // 3. Restored Quick Demo Access Chips (For Nov. 23 Defense Presentation)
            if (!isSignUpMode) {
                Spacer(modifier = Modifier.height(18.dp))
                Text(
                    text = "Quick Demo Access (Tap to auto-fill):",
                    fontSize = 11.sp,
                    color = TextSecondary
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    DemoAccountChip("Resident", Modifier.weight(1f)) {
                        credential = "juan.wawa@nasugbu.ph"
                        password = "••••••••"
                        errorMessage = null
                    }
                    DemoAccountChip("Collector", Modifier.weight(1f)) {
                        credential = "COL-04@nasugbu.gov.ph"
                        password = "••••••••"
                        errorMessage = null
                    }
                    DemoAccountChip("Manager", Modifier.weight(1f)) {
                        credential = "MGR-santos@nasugbu.gov.ph"
                        password = "••••••••"
                        errorMessage = null
                    }
                }
            }
        }
    }
}

@Composable
private fun DemoAccountChip(label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = SurfaceWhite,
        border = BorderStroke(1.dp, BorderLight),
        modifier = modifier.clickable { onClick() }
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.padding(vertical = 8.dp)
        ) {
            Text(
                text = label,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = CoastalTeal
            )
        }
    }
}