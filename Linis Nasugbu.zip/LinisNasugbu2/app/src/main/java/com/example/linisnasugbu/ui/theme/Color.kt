package com.example.linisnasugbu.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Brand Core Colors
val CoastalNavy = Color(0xFF0A2E3D)
val CoastalTeal = Color(0xFF135D66)
val EcoGreen = Color(0xFF1B8A5A)
val MintAccent = Color(0xFFE8F5E9)
val SafetyOrange = Color(0xFFF57C00)
val SoftOrangeBg = Color(0xFFFFF3E0)
val AlertRed = Color(0xFFD32F2F)
val SoftRedBg = Color(0xFFFFEBEE)

// Neutrals
val BackgroundLight = Color(0xFFF6F8FA)
val SurfaceWhite = Color(0xFFFFFFFF)
val TextPrimary = Color(0xFF111827)
val TextSecondary = Color(0xFF6B7280)
val BorderLight = Color(0xFFE5E7EB)

// Grab/Foodpanda-style Hero Gradients
val NasugbuHeroGradient = Brush.linearGradient(
    colors = listOf(CoastalNavy, CoastalTeal, EcoGreen)
)

val PromoCardGradient = Brush.horizontalGradient(
    colors = listOf(Color(0xFF1B8A5A), Color(0xFF2E7D32))
)