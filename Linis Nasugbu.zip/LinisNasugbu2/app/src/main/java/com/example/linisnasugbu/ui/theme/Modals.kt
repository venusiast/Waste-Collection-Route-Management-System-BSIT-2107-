package com.example.linisnasugbu.ui.theme

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun RequestComplaintModal(
    type: String,
    onDismiss: () -> Unit,
    onSubmit: (barangay: String, details: String) -> Unit
) {
    var barangay by remember { mutableStateOf("") }
    var details by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(20.dp),
        title = {
            Text(
                text = if (type == "Bulk Pickup") "Request Bulk Waste Pickup" else "Report Uncollected Waste",
                fontWeight = FontWeight.Bold,
                color = CoastalNavy
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = barangay,
                    onValueChange = { barangay = it },
                    label = { Text("Barangay / Street in Nasugbu") },
                    placeholder = { Text("e.g. Brgy. Wawa, Poblacion 5") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = details,
                    onValueChange = { details = it },
                    label = {
                        Text(
                            if (type == "Bulk Pickup") "Items & Estimated Sacks"
                            else "Issue Description"
                        )
                    },
                    placeholder = {
                        Text(
                            if (type == "Bulk Pickup") "e.g. 3 sacks of tree branches"
                            else "e.g. Missed collection along J.P. Laurel"
                        )
                    },
                    minLines = 3,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (barangay.isNotBlank() && details.isNotBlank()) {
                        onSubmit(barangay, details)
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (type == "Bulk Pickup") EcoGreen else AlertRed
                ),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("Submit Ticket", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun SegregationGuideModal(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(20.dp),
        title = {
            Text("Nasugbu Waste Segregation Guide", fontWeight = FontWeight.Bold, color = CoastalNavy)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                GuideCard("🟢 Nabubulok (Biodegradable)", "Food scraps, leaves, twigs. Collected Mon & Thu.", MintAccent, EcoGreen)
                GuideCard("🟠 Recyclable (Nareresiklo)", "Clean bottles, cans, cardboard, plastics. Collected Tue & Fri.", SoftOrangeBg, SafetyOrange)
                GuideCard("🔴 Residual & Hazardous", "Diapers, sachets, batteries. Keep sealed for Sat pickup.", SoftRedBg, AlertRed)
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = CoastalNavy),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("Got It")
            }
        }
    )
}

@Composable
private fun GuideCard(title: String, desc: String, bg: androidx.compose.ui.graphics.Color, accent: androidx.compose.ui.graphics.Color) {
    Surface(shape = RoundedCornerShape(12.dp), color = bg, modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = accent)
            Spacer(modifier = Modifier.height(2.dp))
            Text(desc, fontSize = 12.sp, color = TextPrimary)
        }
    }
}