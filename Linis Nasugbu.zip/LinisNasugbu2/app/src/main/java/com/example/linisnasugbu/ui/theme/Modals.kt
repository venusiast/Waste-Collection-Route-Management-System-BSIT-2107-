package com.example.linisnasugbu.ui.theme

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SegregationGuideModal(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(20.dp),
        title = {
            Text("Nasugbu Waste Segregation Guide", fontWeight = FontWeight.Bold, color = CoastalNavy)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                GuideCard("🟢 Nabubulok (Biodegradable)", "Food scraps, leaves, twigs. Collected Mon & Thu.", MintAccent, EcoGreen)
                GuideCard("🟠 Recyclable (Nareresiklo)", "Clean bottles, cans, cardboard, plastics. Collected Tue & Fri.", SoftOrangeBg, SafetyOrange)
                GuideCard("🔴 Residual & Hazardous", "Diapers, sachets, batteries. Keep sealed for Sat pickup.", SoftRedBg, AlertRed)
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = CoastalNavy),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("Got It")
            }
        }
    )
}

@Composable
private fun GuideCard(title: String, desc: String, bg: androidx.compose.ui.graphics.Color, accent: androidx.compose.ui.graphics.Color) {
    Surface(shape = RoundedCornerShape(12.dp), color = bg, modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = accent)
            Spacer(modifier = Modifier.height(2.dp))
            Text(desc, fontSize = 12.sp, color = TextPrimary)
        }
    }
}