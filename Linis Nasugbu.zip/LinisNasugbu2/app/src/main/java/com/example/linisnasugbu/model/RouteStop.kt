package com.example.linisnasugbu.model

data class RouteStop(
    val stopId: String,
    val routeId: String,
    val pointId: String,
    val sequenceNumber: Int,
    val estimatedArrival: String,
    var isCompleted: Boolean = false
)
