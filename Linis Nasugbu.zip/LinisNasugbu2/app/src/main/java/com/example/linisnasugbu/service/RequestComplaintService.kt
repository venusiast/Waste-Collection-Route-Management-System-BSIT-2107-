package com.example.linisnasugbu.service

import com.example.linisnasugbu.model.BulkPickupRequest
import com.example.linisnasugbu.model.Complaint
import com.example.linisnasugbu.model.enums.ComplaintStatus
import com.example.linisnasugbu.model.enums.RequestStatus
import java.time.LocalDateTime

class RequestComplaintService {
    private val pickupRequests = mutableListOf<BulkPickupRequest>()
    private val complaints = mutableListOf<Complaint>()

    // --- Bulk Pickup Requests ---
    fun submitPickupRequest(request: BulkPickupRequest) {
        pickupRequests.add(request)
    }

    fun getAllRequests(): List<BulkPickupRequest> = pickupRequests

    fun getRequestsByResident(residentId: String): List<BulkPickupRequest> {
        return pickupRequests.filter { it.residentId == residentId }
    }

    fun updateRequestStatus(requestId: String, newStatus: RequestStatus) {
        val request = pickupRequests.find { it.requestId == requestId }
        request?.let {
            val index = pickupRequests.indexOf(it)
            pickupRequests[index] = it.copy(status = newStatus)
        }
    }

    // --- Complaints ---
    fun fileComplaint(complaint: Complaint) {
        complaints.add(complaint)
    }

    fun getAllComplaints(): List<Complaint> = complaints

    fun getComplaintsByResident(residentId: String): List<Complaint> {
        return complaints.filter { it.residentId == residentId }
    }

    fun respondToComplaint(complaintId: String, responseText: String, newStatus: ComplaintStatus) {
        val complaint = complaints.find { it.complaintId == complaintId }
        complaint?.let {
            val index = complaints.indexOf(it)
            complaints[index] = it.copy(
                status = newStatus,
                response = responseText,
                resolvedDate = LocalDateTime.now()
            )
        }
    }
}
