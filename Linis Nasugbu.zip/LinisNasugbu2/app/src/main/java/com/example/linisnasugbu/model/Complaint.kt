package com.example.linisnasugbu.model

import com.example.linisnasugbu.model.enums.ComplaintStatus
import java.time.LocalDateTime

data class Complaint(
    val complaintId: String,
    val residentId: String,
    val subject: String,
    val message: String,
    val dateFiled: LocalDateTime,
    var status: ComplaintStatus = ComplaintStatus.OPEN,
    val response: String = "",
    val resolvedDate: LocalDateTime? = null
)
