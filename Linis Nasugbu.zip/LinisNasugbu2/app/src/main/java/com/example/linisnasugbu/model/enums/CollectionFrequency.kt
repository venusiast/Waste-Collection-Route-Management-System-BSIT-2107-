package com.example.linisnasugbu.model.enums

enum class CollectionFrequency {
    DAILY,
    MON_THU,
    TUE_FRI,
    WEEKLY,
    MONTHLY
}
