package com.example.linisnasugbu.model

data class WasteFacility(
    val facilityId: String,
    val name: String,
    val location: Location,
    val facilityType: String,
    val contactNumber: String,
    val operatingHours: String,
    val servicesOffered: List<String>
)
