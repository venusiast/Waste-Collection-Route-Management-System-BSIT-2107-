package com.example.linisnasugbu.model.enums

enum class RouteStatus {
    PENDING,
    SCHEDULED,
    IN_PROGRESS,
    COMPLETED,
    MISSED,
    CANCELLED
}