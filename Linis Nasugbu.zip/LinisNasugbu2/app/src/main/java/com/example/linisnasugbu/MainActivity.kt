package com.example.linisnasugbu

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.example.linisnasugbu.service.LinisNasugbuRepository
import com.example.linisnasugbu.ui.theme.BookingsScreen
import com.example.linisnasugbu.ui.theme.HomeScreen
import com.example.linisnasugbu.ui.theme.LoginScreen
import com.example.linisnasugbu.ui.theme.MapTrackerScreen
import com.example.linisnasugbu.ui.theme.NasugbuWasteTheme
import com.example.linisnasugbu.ui.theme.ProfileScreen
import com.example.linisnasugbu.ui.theme.ProfileSetupScreen
import com.example.linisnasugbu.ui.theme.RoleDashboardScreen
import com.example.linisnasugbu.ui.theme.SurfaceWhite

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        LinisNasugbuRepository.loadSession(this)
        setContent {
            NasugbuWasteTheme {
                AppMainNavigation()
            }
        }
    }
}

@Composable
fun AppMainNavigation() {
    val context = LocalContext.current
    val currentUserRole = LinisNasugbuRepository.currentUserRole
    val isProfileCompleted = LinisNasugbuRepository.isProfileCompleted
    val currentUserName = LinisNasugbuRepository.userFullName
    val currentUserAddress = LinisNasugbuRepository.userAddress
    var selectedTab by remember { mutableIntStateOf(0) }

    if (currentUserRole == null) {
        LoginScreen(onLoginSuccess = { role, name ->
            LinisNasugbuRepository.saveSession(
                context = context,
                role = role,
                profileCompleted = false,
                name = name
            )
            selectedTab = 0
        })
    } else if (!isProfileCompleted) {
        val defaultEmail = when (currentUserRole) {
            "Collector" -> "collector@linisnasugbu.ph"
            "Manager" -> "manager@linisnasugbu.ph"
            else -> "resident@linisnasugbu.ph"
        }
        ProfileSetupScreen(
            role = currentUserRole,
            initialName = currentUserName,
            initialEmail = defaultEmail,
            onCompleteSetup = { name, address, phone, email ->
                LinisNasugbuRepository.saveSession(
                    context = context,
                    role = currentUserRole,
                    profileCompleted = true,
                    name = name,
                    address = address,
                    phone = phone,
                    email = email
                )
            }
        )
    } else {
        val tab0Label = when (currentUserRole) {
            "Collector" -> "My Route"
            "Manager" -> "Operations"
            else -> "Home"
        }
        val tab2Label = when (currentUserRole) {
            "Manager" -> "Approvals"
            else -> "Requests"
        }

        Scaffold(
            bottomBar = {
                NavigationBar(containerColor = SurfaceWhite) {
                    NavigationBarItem(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        icon = { Icon(Icons.Default.Home, contentDescription = tab0Label) },
                        label = { Text(tab0Label) }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        icon = { Icon(Icons.Default.LocationOn, contentDescription = "Live Map") },
                        label = { Text("Live Map") }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        icon = { Icon(Icons.Default.DateRange, contentDescription = tab2Label) },
                        label = { Text(tab2Label) }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 3,
                        onClick = { selectedTab = 3 },
                        icon = { Icon(Icons.Default.Person, contentDescription = "Profile") },
                        label = { Text("Profile") }
                    )
                }
            }
        ) { innerPadding ->
            Surface(modifier = Modifier.padding(innerPadding)) {
                when (selectedTab) {
                    0 -> {
                        if (currentUserRole == "Resident") {
                            HomeScreen(
                                userName = currentUserName,
                                barangay = currentUserAddress,
                                onNavigateTab = { tabIndex -> selectedTab = tabIndex }
                            )
                        } else {
                            RoleDashboardScreen(
                                role = currentUserRole,
                                userName = currentUserName
                            )
                        }
                    }
                    1 -> MapTrackerScreen()
                    2 -> BookingsScreen(
                        role = currentUserRole,
                        userName = currentUserName
                    )
                    3 -> ProfileScreen(
                        role = currentUserRole,
                        userName = currentUserName,
                        onLogout = {
                            LinisNasugbuRepository.clearSession(context)
                        }
                    )
                }
            }
        }
    }
}