package com.example.linisnasugbu.model.enums

enum class UserRole {
    RESIDENT,
    COLLECTOR,
    MANAGER
}
