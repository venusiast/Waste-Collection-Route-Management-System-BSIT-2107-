package com.example.linisnasugbu.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.linisnasugbu.service.LinisNasugbuRepository
import org.maplibre.android.MapLibre
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView

@Composable
fun MapTrackerScreen() {
    val context = LocalContext.current
    remember { MapLibre.getInstance(context) }

    val stops = LinisNasugbuRepository.routeStops
    val currentIdx = LinisNasugbuRepository.currentStopIndex.coerceIn(0, (stops.size - 1).coerceAtLeast(0))
    val activeStop = stops.getOrNull(currentIdx)

    val truckLat = activeStop?.lat ?: 14.0725
    val truckLng = activeStop?.lng ?: 120.6322

    var mapLibreInstance by remember { mutableStateOf<MapLibreMap?>(null) }

    LaunchedEffect(truckLat, truckLng, mapLibreInstance) {
        mapLibreInstance?.animateCamera(
            CameraUpdateFactory.newCameraPosition(
                CameraPosition.Builder()
                    .target(LatLng(truckLat, truckLng))
                    .zoom(15.0)
                    .build()
            ),
            1000
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundLight)
    ) {
        // Top Gradient Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp))
                .background(NasugbuHeroGradient)
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Live GPS Truck Tracker", color = SurfaceWhite, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Nasugbu Coastal & Poblacion Loop", color = SurfaceWhite.copy(alpha = 0.85f), fontSize = 12.sp)
                }
                Surface(shape = RoundedCornerShape(20.dp), color = EcoGreen) {
                    Text(
                        "GPS LIVE",
                        color = SurfaceWhite,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }
        }

        // OpenFreeMap Vector Map Container
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(16.dp)
                .clip(RoundedCornerShape(20.dp)),
            contentAlignment = Alignment.Center
        ) {
            AndroidView(
                factory = { ctx ->
                    MapView(ctx).apply {
                        getMapAsync { map ->
                            mapLibreInstance = map
                            map.setStyle("https://tiles.openfreemap.org/styles/liberty") {
                                map.cameraPosition = CameraPosition.Builder()
                                    .target(LatLng(truckLat, truckLng))
                                    .zoom(14.5)
                                    .build()
                            }
                        }
                    }
                },
                modifier = Modifier.fillMaxSize()
            )

            // Center Live Truck Pin Overlay
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Surface(shape = CircleShape, color = SurfaceWhite, shadowElevation = 6.dp) {
                    Icon(
                        Icons.Default.LocationOn,
                        contentDescription = null,
                        tint = AlertRed,
                        modifier = Modifier.padding(8.dp).size(32.dp)
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Surface(shape = RoundedCornerShape(8.dp), color = CoastalNavy, shadowElevation = 4.dp) {
                    Text(
                        text = "Truck #04 • ${activeStop?.stopName ?: "Nasugbu Loop"}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = SurfaceWhite,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }
        }

        // Bottom Telemetry & GPS Simulation Card
        Card(
            shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
            elevation = CardDefaults.cardElevation(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("CURRENT SECTOR", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = EcoGreen)
                        Text(
                            text = activeStop?.stopName ?: "En Route",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = TextPrimary
                        )
                        Text(
                            text = "Coordinates: $truckLat° N, $truckLng° E",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                    }

                    Surface(shape = RoundedCornerShape(12.dp), color = SoftOrangeBg) {
                        Text(
                            text = "ETA: ${(currentIdx + 1) * 4} mins",
                            color = SafetyOrange,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = { LinisNasugbuRepository.advanceTruckLocation() },
                    colors = ButtonDefaults.buttonColors(containerColor = CoastalNavy),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().height(46.dp)
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Simulate Truck Movement (Next Stop)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
    }
}