package com.example.linisnasugbu.service

import com.example.linisnasugbu.model.Route
import com.example.linisnasugbu.model.RouteStop

class RouteOptimizerService {

    // Simple reordering: resequence stops by given order
    fun reorderStops(route: Route, newOrder: List<String>): Route {
        val newStops = mutableListOf<RouteStop>()

        newOrder.forEachIndexed { index, stopId ->
            val stop = route.stops.find { it.stopId == stopId }
            if (stop != null) {
                newStops.add(stop.copy(sequenceNumber = index + 1))
            }
        }

        // Keep stops not in newOrder at the end
        val remainingStops = route.stops.filter { it.stopId !in newOrder }
        remainingStops.forEachIndexed { index, stop ->
            newStops.add(stop.copy(sequenceNumber = newOrder.size + index + 1))
        }

        return route.copy(stops = newStops)
    }

    // Mark a stop as completed
    fun markStopCompleted(route: Route, stopId: String): Route {
        val updatedStops = route.stops.map { stop ->
            if (stop.stopId == stopId) stop.copy(isCompleted = true) else stop
        }.toMutableList()
        return route.copy(stops = updatedStops)
    }

    // Calculate completion percentage
    fun getRouteProgress(route: Route): Double {
        if (route.stops.isEmpty()) return 0.0
        val completed = route.stops.count { it.isCompleted }
        return (completed.toDouble() / route.stops.size) * 100
    }
}
