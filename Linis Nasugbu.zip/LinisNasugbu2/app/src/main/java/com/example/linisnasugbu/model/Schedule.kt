package com.example.linisnasugbu.model

import com.example.linisnasugbu.model.enums.CollectionFrequency
import com.example.linisnasugbu.model.enums.DayOfWeek
import com.example.linisnasugbu.model.enums.WasteType

data class Schedule(
    val scheduleId: String,
    val pointId: String,
    val day: DayOfWeek,
    val timeStart: String,
    val timeEnd: String,
    val wasteType: WasteType,
    val frequency: CollectionFrequency
)
