package com.example.linisnasugbu.service

// Placeholder service — for OOP 1, just simulate notifications
class NotificationService {

    fun sendScheduleRemediation(recipient: String, day: String, time: String) {
        println("🔔 Notification to $recipient: Collection is on $day at $time")
    }

    fun sendRequestUpdate(requestId: String, newStatus: String) {
        println("🔔 Request $requestId status updated to: $newStatus")
    }

    fun sendRouteNotification(collectorId: String, routeName: String) {
        println("🔔 Assigned Route: '$routeName' sent to Collector $collectorId")
    }
}
