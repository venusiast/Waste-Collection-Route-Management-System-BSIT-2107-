package com.example.linisnasugbu.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.linisnasugbu.service.LinisNasugbuRepository

@Composable
fun RoleDashboardScreen(
    role: String,
    userName: String = if (role == "Manager") "Engr. Maria Santos" else "Kuya Pedro Reyes"
) {
    val stops = LinisNasugbuRepository.routeStops
    val pendingTicketsCount = LinisNasugbuRepository.tickets.count { it.status == "Pending" }
    val completedCount = stops.count { it.isCompleted }
    val progress = if (stops.isNotEmpty()) completedCount.toFloat() / stops.size else 0f

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundLight),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        // Gradient Header
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
                    .background(NasugbuHeroGradient)
                    .padding(horizontal = 20.dp, vertical = 24.dp)
            ) {
                Column {
                    Surface(shape = RoundedCornerShape(20.dp), color = SafetyOrange) {
                        Text(
                            text = if (role == "Manager") "MUNICIPAL OPERATIONS" else "FIELD COLLECTOR • TRUCK #04",
                            color = SurfaceWhite,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text("Mabuhay, $userName!", color = SurfaceWhite, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text(
                        text = if (role == "Manager") "Nasugbu Fleet & Waste Facility Overview" else "Active Route: Poblacion – Coastal Loop",
                        color = SurfaceWhite.copy(alpha = 0.85f),
                        fontSize = 13.sp
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = SurfaceWhite.copy(alpha = 0.14f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Today's Collection Progress", color = SurfaceWhite, fontSize = 12.sp)
                                Text("$completedCount / ${stops.size} Stops", color = SurfaceWhite, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            LinearProgressIndicator(
                                progress = { progress },
                                modifier = Modifier.fillMaxWidth().height(7.dp).clip(CircleShape),
                                color = SafetyOrange,
                                trackColor = SurfaceWhite.copy(alpha = 0.25f)
                            )
                        }
                    }
                }
            }
        }

        // Manager KPI Cards
        if (role == "Manager") {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    ProStatCard("Active Fleet", "4 / 5 Trucks", EcoGreen, MintAccent, Modifier.weight(1f))
                    ProStatCard("Pending", "$pendingTicketsCount Tickets", SafetyOrange, SoftOrangeBg, Modifier.weight(1f))
                    ProStatCard("MRF Load", "68% Cap.", CoastalTeal, Color(0xFFE0F2F1), Modifier.weight(1f))
                }
            }
        }

        // Route Optimizer Button + Optimization Result Banner
        item {
            Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp)) {
                Button(
                    onClick = { LinisNasugbuRepository.optimizeNasugbuRoute() },
                    colors = ButtonDefaults.buttonColors(containerColor = EcoGreen),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    elevation = ButtonDefaults.buttonElevation(4.dp)
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Optimize Shortest Route (Nasugbu GPS)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }

                if (LinisNasugbuRepository.isRouteOptimized) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(shape = RoundedCornerShape(10.dp), color = MintAccent, modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = "✅ ${LinisNasugbuRepository.savedDistanceText}",
                            color = EcoGreen,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = if (role == "Manager") "Live Route Checkpoints" else "Tap Checkbox Upon Collection",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = TextPrimary
                )
            }
        }

        // Interactive Route Stops
        itemsIndexed(stops) { index, stop ->
            Card(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 5.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (stop.isCompleted) MintAccent.copy(alpha = 0.6f) else SurfaceWhite
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = if (stop.isCompleted) 0.dp else 2.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp).fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Surface(
                            shape = CircleShape,
                            color = if (stop.isCompleted) EcoGreen else SoftRedBg,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = if (stop.isCompleted) Icons.Default.Check else Icons.Default.LocationOn,
                                    contentDescription = null,
                                    tint = if (stop.isCompleted) SurfaceWhite else AlertRed,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(stop.stopName, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = TextPrimary)
                            Text("${stop.zone} • ${stop.estimatedLoad} (${stop.distanceKm} km)", fontSize = 12.sp, color = TextSecondary)
                        }
                    }

                    Checkbox(
                        checked = stop.isCompleted,
                        onCheckedChange = { checked -> LinisNasugbuRepository.toggleStopCompletion(index, checked) },
                        colors = CheckboxDefaults.colors(checkedColor = EcoGreen)
                    )
                }
            }
        }
    }
}

@Composable
fun ProStatCard(title: String, value: String, accent: Color, bg: Color, modifier: Modifier = Modifier) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
        elevation = CardDefaults.cardElevation(2.dp),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Surface(shape = CircleShape, color = bg, modifier = Modifier.size(8.dp)) {}
            Spacer(modifier = Modifier.height(6.dp))
            Text(title, fontSize = 11.sp, color = TextSecondary)
            Text(value, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = accent)
        }
    }
}