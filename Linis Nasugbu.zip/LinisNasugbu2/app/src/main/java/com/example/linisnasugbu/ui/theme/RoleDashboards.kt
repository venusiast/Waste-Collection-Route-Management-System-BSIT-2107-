package com.example.linisnasugbu.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.linisnasugbu.service.LinisNasugbuRepository

@Composable
fun RoleDashboardScreen(
    role: String,
    userName: String = if (role == "Manager") "Engr. Maria Santos" else "Kuya Pedro Reyes"
) {
    val currentUser = LinisNasugbuRepository.activeUser
    val stops = LinisNasugbuRepository.routeStops
    val tickets = LinisNasugbuRepository.tickets
    val zones = LinisNasugbuRepository.zoneAssignments
    val fleet = LinisNasugbuRepository.fleetVehicles

    val pendingTickets = tickets.filter { it.status == "Pending" || it.status == "Processed" }
    val rescheduledStops = stops.filter { it.collectionStatus == "Rescheduled" }
    val completedCount = stops.count { it.collectionStatus == "Collected" }
    val progress = if (stops.isNotEmpty()) completedCount.toFloat() / stops.size else 0f

    // Scenario 3: Payload capacity calculation (Low / Medium / Heavy)
    val capacityPercent = LinisNasugbuRepository.activeCapacityPercent
    val capacityRatio = (capacityPercent / 100f).coerceIn(0f, 1f)
    val capacityLabel = when {
        capacityPercent >= 80 -> "Heavy ($capacityPercent%)"
        capacityPercent >= 45 -> "Medium ($capacityPercent%)"
        else -> "Low ($capacityPercent%)"
    }
    val isNearCapacity = capacityPercent >= 80

    val issueCategories = listOf(
        "Road Blocked / Construction",
        "Flooded / Impassable Street",
        "Truck Capacity Full (MRF Unload Needed)",
        "Unsegregated / Hazardous Waste"
    )
    var skipDialogIndex by remember { mutableStateOf<Int?>(null) }
    var selectedReason by remember { mutableStateOf(issueCategories.first()) }
    var additionalNotes by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundLight),
        contentPadding = PaddingValues(bottom = 110.dp)
    ) {
        // Gradient Header
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
                    .background(NasugbuHeroGradient)
                    .padding(horizontal = 20.dp, vertical = 24.dp)
            ) {
                Column {
                    Surface(shape = RoundedCornerShape(20.dp), color = SafetyOrange) {
                        Text(
                            text = currentUser.getDisplayBadge(),
                            color = SurfaceWhite,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text("Mabuhay, $userName!", color = SurfaceWhite, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text(
                        text = currentUser.getDashboardSummary(),
                        color = SurfaceWhite.copy(alpha = 0.85f),
                        fontSize = 13.sp
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    // Progress + Truck Estimated Load Card (Scenario 3 & 4)
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = SurfaceWhite.copy(alpha = 0.14f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Collection Progress", color = SurfaceWhite, fontSize = 12.sp)
                                Text(
                                    "$completedCount / ${stops.size} Stops (${rescheduledStops.size} Resched)",
                                    color = SurfaceWhite,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            LinearProgressIndicator(
                                progress = { progress },
                                modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
                                color = EcoGreen,
                                trackColor = SurfaceWhite.copy(alpha = 0.25f)
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            // Scenario 3: Truck Estimated Load Gauge
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Truck #04 Estimated Load", color = SurfaceWhite, fontSize = 12.sp)
                                Text(
                                    text = capacityLabel,
                                    color = if (isNearCapacity) SafetyOrange else SurfaceWhite,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            LinearProgressIndicator(
                                progress = { capacityRatio },
                                modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
                                color = if (isNearCapacity) AlertRed else SafetyOrange,
                                trackColor = SurfaceWhite.copy(alpha = 0.25f)
                            )
                            if (isNearCapacity) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "⚠ Heavy Load Warning: Plan MRF unload before adding extra stops.",
                                    color = SurfaceWhite,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
            }
        }

        // MANAGER OPERATIONS CONTROLS (Scenarios 2, 4, 5, 6)
        if (role == "Manager") {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    ProStatCard("Active Fleet", "4 / 5 Trucks", EcoGreen, MintAccent, Modifier.weight(1f))
                    ProStatCard("For Review", "${pendingTickets.size} Reports", SafetyOrange, SoftOrangeBg, Modifier.weight(1f))
                    ProStatCard("Rescheduled", "${rescheduledStops.size} Stops", AlertRed, SoftRedBg, Modifier.weight(1f))
                }
            }

            // Scenario 5 Alert Banner: Collection Issue & Auto-Reschedule
            if (rescheduledStops.isNotEmpty()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = SoftRedBg),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 4.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = AlertRed, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("COLLECTION ISSUE • AUTO-RESCHEDULED", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = AlertRed)
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            rescheduledStops.forEach { stop ->
                                Text(
                                    text = "• ${stop.stopName}: ${stop.skipReason} (Swapped to next cycle)",
                                    fontSize = 12.sp,
                                    color = TextPrimary
                                )
                            }
                        }
                    }
                }
            }

            // Scenario 2: Zone Coverage & Non-Overlapping Schedules
            item {
                Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp)) {
                    Text("Zone Boundaries & Schedule Coverage", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = TextPrimary)
                    Spacer(modifier = Modifier.height(8.dp))
                    Card(
                        colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                        shape = RoundedCornerShape(16.dp),
                        elevation = CardDefaults.cardElevation(2.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            zones.forEachIndexed { idx, zone ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(zone.zoneName, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = TextPrimary)
                                        Text("${zone.assignedTruck} • ${zone.scheduleDay}", fontSize = 11.sp, color = TextSecondary)
                                    }
                                    if (zone.isCovered) {
                                        Surface(shape = RoundedCornerShape(8.dp), color = MintAccent) {
                                            Text(
                                                text = "COVERED",
                                                color = EcoGreen,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                            )
                                        }
                                    } else {
                                        Button(
                                            onClick = { LinisNasugbuRepository.assignTruckToUncoveredZone(idx) },
                                            colors = ButtonDefaults.buttonColors(containerColor = SafetyOrange),
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                            modifier = Modifier.height(30.dp)
                                        ) {
                                            Text("Assign Truck #03", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Scenario 6: Fleet Workload Distribution & Balancer
            item {
                Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)) {
                    Text("Fleet Workload Distribution", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = TextPrimary)
                    Spacer(modifier = Modifier.height(8.dp))
                    Card(
                        colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                        shape = RoundedCornerShape(16.dp),
                        elevation = CardDefaults.cardElevation(2.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            fleet.forEach { vehicle ->
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("${vehicle.truckId} (${vehicle.assignedZone})", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = TextPrimary)
                                    Text("${vehicle.stopCount} stops • ${vehicle.loadStatus}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CoastalNavy)
                                }
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            OutlinedButton(
                                onClick = { LinisNasugbuRepository.balanceFleetWorkload() },
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth().height(38.dp)
                            ) {
                                Text(
                                    text = if (LinisNasugbuRepository.isFleetBalanced) "✓ Fleet Workload Balanced" else "Redistribute & Balance Fleet Workload",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = CoastalNavy
                                )
                            }
                            if (LinisNasugbuRepository.isFleetBalanced) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(LinisNasugbuRepository.fleetBalanceMessage, fontSize = 11.sp, color = EcoGreen, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            }

            // Scenario 4: Manager Quick Evaluation & Acceptance Panel sa Main Dashboard
            if (pendingTickets.isNotEmpty()) {
                item {
                    Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp)) {
                        Text("Complaints & Requests for Evaluation", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = TextPrimary)
                        Spacer(modifier = Modifier.height(8.dp))
                        pendingTickets.forEach { ticket ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                                shape = RoundedCornerShape(14.dp),
                                elevation = CardDefaults.cardElevation(2.dp),
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("${ticket.id} • ${ticket.barangay}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = CoastalNavy)
                                        Text(
                                            text = if (ticket.status == "Pending") "FOR REVIEW" else "EVALUATED",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = SafetyOrange
                                        )
                                    }
                                    Text("${ticket.type}: ${ticket.description}", fontSize = 12.sp, color = TextSecondary)
                                    Spacer(modifier = Modifier.height(8.dp))
                                    if (ticket.status == "Pending") {
                                        Button(
                                            onClick = { LinisNasugbuRepository.processTicket(ticket.id) },
                                            colors = ButtonDefaults.buttonColors(containerColor = CoastalNavy),
                                            shape = RoundedCornerShape(10.dp),
                                            modifier = Modifier.fillMaxWidth().height(38.dp)
                                        ) {
                                            Text("Mark as Reviewed & Evaluated", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        }
                                    } else {
                                        Button(
                                            onClick = { LinisNasugbuRepository.approveTicketAndAssign(ticket.id) },
                                            colors = ButtonDefaults.buttonColors(containerColor = EcoGreen),
                                            shape = RoundedCornerShape(10.dp),
                                            modifier = Modifier.fillMaxWidth().height(38.dp)
                                        ) {
                                            Text("Accept & Dispatch to Collector Route", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Scenario 1: Route Optimizer Button
        item {
            Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp)) {
                Button(
                    onClick = { LinisNasugbuRepository.optimizeNasugbuRoute() },
                    colors = ButtonDefaults.buttonColors(containerColor = EcoGreen),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    elevation = ButtonDefaults.buttonElevation(4.dp)
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Optimize Shortest Route (Nasugbu GPS)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }

                if (LinisNasugbuRepository.isRouteOptimized) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(shape = RoundedCornerShape(10.dp), color = MintAccent, modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = "✅ ${LinisNasugbuRepository.savedDistanceText}",
                            color = EcoGreen,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = if (role == "Manager") "Live Route Checkpoints Status" else "Barangay Collection Stops",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = TextPrimary
                )
            }
        }

        // Interactive Route Stops with Proper Collection & Issue/Reschedule Actions
        itemsIndexed(stops) { index, stop ->
            val isCollected = stop.collectionStatus == "Collected"
            val isRescheduled = stop.collectionStatus == "Rescheduled"

            Card(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = when {
                        isCollected -> MintAccent.copy(alpha = 0.65f)
                        isRescheduled -> SoftRedBg.copy(alpha = 0.85f)
                        else -> SurfaceWhite
                    }
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Surface(
                                shape = CircleShape,
                                color = when {
                                    isCollected -> EcoGreen
                                    isRescheduled -> AlertRed
                                    else -> SoftOrangeBg
                                },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = when {
                                            isCollected -> Icons.Default.Check
                                            isRescheduled -> Icons.Default.Warning
                                            else -> Icons.Default.LocationOn
                                        },
                                        contentDescription = null,
                                        tint = if (isCollected || isRescheduled) SurfaceWhite else SafetyOrange,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(stop.stopName, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = TextPrimary)
                                Text("${stop.zone} • ${stop.estimatedLoad} (${stop.distanceKm} km)", fontSize = 12.sp, color = TextSecondary)
                                if (isRescheduled) {
                                    Text(
                                        text = "⚠ Rescheduled: ${stop.skipReason}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = AlertRed
                                    )
                                }
                            }
                        }
                    }

                    // Collector Actions: Mark Collected vs. Report Issue / Reschedule
                    if (role == "Collector") {
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            Button(
                                onClick = {
                                    LinisNasugbuRepository.updateStopStatus(
                                        index = index,
                                        newStatus = if (isCollected) "Pending" else "Collected"
                                    )
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isCollected) CoastalTeal else EcoGreen
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1f).height(40.dp)
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(if (isCollected) "Collected ✓" else "Mark Collected", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }

                            OutlinedButton(
                                onClick = {
                                    selectedReason = issueCategories.first()
                                    additionalNotes = ""
                                    skipDialogIndex = index
                                },
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1f).height(40.dp)
                            ) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = AlertRed, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Report Issue", fontSize = 12.sp, color = AlertRed, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }

    // Dialog kapag may na-encounter na problema at kailangang i-reschedule ang area
    if (skipDialogIndex != null) {
        AlertDialog(
            onDismissRequest = { skipDialogIndex = null },
            shape = RoundedCornerShape(20.dp),
            title = { Text("Report Collection Issue & Reschedule", fontWeight = FontWeight.Bold, color = CoastalNavy) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Select encountered problem:", fontSize = 13.sp, color = TextSecondary)
                    issueCategories.forEach { reason ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            RadioButton(
                                selected = selectedReason == reason,
                                onClick = { selectedReason = reason }
                            )
                            Text(reason, fontSize = 13.sp, color = TextPrimary)
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = additionalNotes,
                        onValueChange = { additionalNotes = it },
                        label = { Text("Additional details (Optional)") },
                        placeholder = { Text("e.g., Bridge repair until tomorrow") },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val finalReason = if (additionalNotes.isNotBlank()) {
                            "$selectedReason — ${additionalNotes.trim()}"
                        } else {
                            selectedReason
                        }
                        LinisNasugbuRepository.updateStopStatus(
                            index = skipDialogIndex!!,
                            newStatus = "Rescheduled",
                            reason = finalReason
                        )
                        skipDialogIndex = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AlertRed)
                ) {
                    Text("Submit & Reschedule", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { skipDialogIndex = null }) { Text("Cancel") }
            }
        )
    }
}

@Composable
fun ProStatCard(title: String, value: String, accent: Color, bg: Color, modifier: Modifier = Modifier) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
        elevation = CardDefaults.cardElevation(2.dp),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Surface(shape = CircleShape, color = bg, modifier = Modifier.size(8.dp)) {}
            Spacer(modifier = Modifier.height(6.dp))
            Text(title, fontSize = 11.sp, color = TextSecondary)
            Text(value, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = accent)
        }
    }
}