package com.example.linisnasugbu.service

import com.example.linisnasugbu.model.CollectionPoint
import com.example.linisnasugbu.model.Route
import com.example.linisnasugbu.model.Schedule
import com.example.linisnasugbu.model.enums.DayOfWeek
import com.example.linisnasugbu.model.enums.WasteType

class WasteCollectionService {
    private val collectionPoints = mutableListOf<CollectionPoint>()
    private val schedules = mutableListOf<Schedule>()
    private val routes = mutableListOf<Route>()

    // --- Collection Point Management ---
    fun addCollectionPoint(point: CollectionPoint) {
        collectionPoints.add(point)
    }

    fun getAllCollectionPoints(): List<CollectionPoint> = collectionPoints

    fun getPointsByZone(zone: String): List<CollectionPoint> {
        return collectionPoints.filter { it.location.zone == zone && it.isActive }
    }

    // --- Schedule Management ---
    fun addSchedule(schedule: Schedule) {
        schedules.add(schedule)
    }

    fun getSchedulesByPoint(pointId: String): List<Schedule> {
        return schedules.filter { it.pointId == pointId }
    }

    fun getSchedulesByDay(day: DayOfWeek): List<Schedule> {
        return schedules.filter { it.day == day }
    }

    fun getSchedulesByZoneAndDay(zone: String, day: DayOfWeek): List<Schedule> {
        val pointIds = getPointsByZone(zone).map { it.pointId }
        return schedules.filter { it.pointId in pointIds && it.day == day }
    }

    // --- Route Management ---
    fun addRoute(route: Route) {
        routes.add(route)
    }

    fun getAllRoutes(): List<Route> = routes

    fun getRoutesByCollector(collectorId: String): List<Route> {
        return routes.filter { it.assignedCollectorId == collectorId }
    }

    fun getRouteById(routeId: String): Route? {
        return routes.find { it.routeId == routeId }
    }

    fun updateRouteStatus(routeId: String, newStatus: com.example.linisnasugbu.model.enums.RouteStatus) {
        val route = getRouteById(routeId)
        route?.let {
            val index = routes.indexOf(it)
            routes[index] = it.copy(status = newStatus)
        }
    }
}
