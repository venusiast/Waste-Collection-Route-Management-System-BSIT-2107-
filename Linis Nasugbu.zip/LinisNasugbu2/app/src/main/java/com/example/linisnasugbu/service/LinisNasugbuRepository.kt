package com.example.linisnasugbu.service

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

data class TicketItem(
    val id: String,
    val residentName: String,
    val type: String, // "Bulk Pickup" or "Complaint"
    val barangay: String,
    val description: String,
    var status: String // "Pending", "Processed", "Approved", "Completed"
)

data class RouteCheckpoint(
    val id: String,
    val stopName: String,
    val zone: String,
    val estimatedLoad: String,
    val distanceKm: Double,
    val lat: Double,
    val lng: Double,
    var isCompleted: Boolean = false
)

object LinisNasugbuRepository {
    private const val PREFS_NAME = "linis_nasugbu_prefs"

    // Session & Active User Profile State
    var currentUserRole by mutableStateOf<String?>(null)
    var isProfileCompleted by mutableStateOf(false)
    var userFullName by mutableStateOf("Juan Dela Cruz")
    var userAddress by mutableStateOf("Brgy. Wawa, Nasugbu")
    var userPhone by mutableStateOf("0917-555-0192")
    var userEmail by mutableStateOf("resident@linisnasugbu.ph")

    fun loadSession(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        currentUserRole = prefs.getString("role", null)
        isProfileCompleted = prefs.getBoolean("is_profile_completed", false)
        userFullName = prefs.getString("full_name", "Juan Dela Cruz") ?: "Juan Dela Cruz"
        userAddress = prefs.getString("address", "Brgy. Wawa, Nasugbu") ?: "Brgy. Wawa, Nasugbu"
        userPhone = prefs.getString("phone", "0917-555-0192") ?: "0917-555-0192"
        userEmail = prefs.getString("email", "resident@linisnasugbu.ph") ?: "resident@linisnasugbu.ph"
    }

    fun saveSession(
        context: Context,
        role: String?,
        profileCompleted: Boolean,
        name: String = userFullName,
        address: String = userAddress,
        phone: String = userPhone,
        email: String = userEmail
    ) {
        currentUserRole = role
        isProfileCompleted = profileCompleted
        userFullName = name
        userAddress = address
        userPhone = phone
        userEmail = email

        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().apply {
            putString("role", role)
            putBoolean("is_profile_completed", profileCompleted)
            putString("full_name", name)
            putString("address", address)
            putString("phone", phone)
            putString("email", email)
            apply()
        }
    }

    fun clearSession(context: Context) {
        currentUserRole = null
        isProfileCompleted = false
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().clear().apply()
    }

    // Shared Tickets
    val tickets = mutableStateListOf(
        TicketItem("REQ-101", "Juan Dela Cruz", "Bulk Pickup", "Brgy. Wawa", "Garden trimmings & 2 sacks", "Approved"),
        TicketItem("CMP-102", "Maria Clara", "Complaint", "Brgy. 5 Poblacion", "Delayed morning collection", "Completed")
    )

    // Shared Nasugbu Route Checkpoints
    val routeStops = mutableStateListOf(
        RouteCheckpoint("STP-1", "Brgy. Wawa Port Terminal", "Coastal Sector", "~450 kg • Biodegradable", 1.2, 14.0835, 120.6214, true),
        RouteCheckpoint("STP-2", "Nasugbu Public Market", "Poblacion Zone", "~1,200 kg • Mixed Waste", 3.8, 14.0725, 120.6322, false),
        RouteCheckpoint("STP-3", "Brgy. Bucana Coastal Road", "Coastal Sector", "~380 kg • Residual", 2.1, 14.0618, 120.6250, false),
        RouteCheckpoint("STP-4", "Nasugbu Sanitary MRF", "Disposal Facility", "Unload & Weigh-in", 5.4, 14.0910, 120.6580, false)
    )

    var currentStopIndex by mutableIntStateOf(1)
    var isRouteOptimized by mutableStateOf(false)
    var savedDistanceText by mutableStateOf("")

    fun submitTicket(residentName: String, type: String, barangay: String, description: String) {
        val prefix = if (type == "Bulk Pickup") "REQ" else "CMP"
        val newId = "$prefix-${103 + tickets.size}"
        tickets.add(0, TicketItem(newId, residentName, type, barangay, description, "Pending"))
    }

    fun processTicket(ticketId: String) {
        val index = tickets.indexOfFirst { it.id == ticketId }
        if (index != -1) {
            tickets[index] = tickets[index].copy(status = "Processed")
        }
    }

    fun approveTicketAndAssign(ticketId: String) {
        val index = tickets.indexOfFirst { it.id == ticketId }
        if (index != -1) {
            val ticket = tickets[index]
            tickets[index] = ticket.copy(status = "Approved")
            routeStops.add(
                (routeStops.size - 1).coerceAtLeast(0),
                RouteCheckpoint(
                    id = ticket.id,
                    stopName = "${ticket.type}: ${ticket.barangay}",
                    zone = "Special Dispatch (${ticket.residentName})",
                    estimatedLoad = ticket.description,
                    distanceKm = 1.5,
                    lat = 14.0750,
                    lng = 120.6340,
                    isCompleted = false
                )
            )
        }
    }

    fun toggleStopCompletion(index: Int, completed: Boolean) {
        val stop = routeStops[index]
        routeStops[index] = stop.copy(isCompleted = completed)

        val ticketIdx = tickets.indexOfFirst { it.id == stop.id }
        if (ticketIdx != -1) {
            tickets[ticketIdx] = tickets[ticketIdx].copy(
                status = if (completed) "Completed" else "Approved"
            )
        }
    }

    fun optimizeNasugbuRoute() {
        val completed = routeStops.filter { it.isCompleted }
        val finalDrop = routeStops.lastOrNull { it.zone == "Disposal Facility" }
        val pendingMiddle = routeStops.filter { !it.isCompleted && it != finalDrop }
            .sortedBy { it.distanceKm }

        routeStops.clear()
        routeStops.addAll(completed)
        routeStops.addAll(pendingMiddle)
        if (finalDrop != null && !finalDrop.isCompleted) {
            routeStops.add(finalDrop)
        }

        isRouteOptimized = true
        savedDistanceText = "Route Optimized: 14.2 km → 11.6 km (Saved 2.6 km)"
    }

    fun advanceTruckLocation() {
        if (routeStops.isNotEmpty()) {
            currentStopIndex = (currentStopIndex + 1) % routeStops.size
        }
    }
}