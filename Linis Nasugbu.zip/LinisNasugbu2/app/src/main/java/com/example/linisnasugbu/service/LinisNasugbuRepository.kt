package com.example.linisnasugbu.service

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.example.linisnasugbu.model.CollectionPoint
import com.example.linisnasugbu.model.Collector
import com.example.linisnasugbu.model.Location
import com.example.linisnasugbu.model.Manager
import com.example.linisnasugbu.model.Resident
import com.example.linisnasugbu.model.Route
import com.example.linisnasugbu.model.RouteStop
import com.example.linisnasugbu.model.User
import com.example.linisnasugbu.model.enums.WasteType

data class TicketItem(
    val id: String,
    val residentName: String,
    val type: String, // "Bulk Pickup" or "Complaint"
    val barangay: String,
    val description: String,
    var status: String, // "Pending", "Processed", "Approved", "Completed", or "Rescheduled (...)"
    var resolutionNote: String = "Awaiting MENRO evaluation"
)

data class RegisteredAccount(
    val email: String,
    val password: String,
    val fullName: String
)

data class RouteCheckpoint(
    val id: String,
    val stopName: String,
    val zone: String,
    val estimatedLoad: String,
    val loadLevel: String, // "Low", "Medium", "Heavy"
    val distanceKm: Double,
    val lat: Double,
    val lng: Double,
    var isCompleted: Boolean = false,
    var collectionStatus: String = if (isCompleted) "Collected" else "Pending",
    var skipReason: String = ""
) {
    // Topic 4: Member method encapsulating payload weight calculation
    fun getCapacityWeight(): Int {
        if (collectionStatus == "Rescheduled" || zone == "Disposal Facility") return 0
        return when (loadLevel) {
            "Heavy" -> 45
            "Medium" -> 25
            else -> 15
        }
    }
}

data class ZoneAssignment(
    val zoneName: String,
    val assignedTruck: String,
    val scheduleDay: String,
    val isCovered: Boolean
)

data class FleetVehicle(
    val truckId: String,
    val driverName: String,
    val assignedZone: String,
    val stopCount: Int,
    val loadStatus: String
)

object LinisNasugbuRepository {
    private const val PREFS_NAME = "linis_nasugbu_prefs"

    // Topic 7: Object Collaboration with Domain Services
    val wasteCollectionService = WasteCollectionService()
    val routeOptimizerService = RouteOptimizerService()

    // Registered Resident Accounts (Topic 3: Collections of Objects)
    val registeredAccounts = mutableStateListOf(
        RegisteredAccount("juan.wawa@nasugbu.ph", "123456", "Juan Dela Cruz")
    )

    // Session & Active User Profile State
    var currentUserRole by mutableStateOf<String?>(null)
    var isProfileCompleted by mutableStateOf(false)
    var userFullName by mutableStateOf("Juan Dela Cruz")
    var userAddress by mutableStateOf("Brgy. Wawa, Nasugbu")
    var userPhone by mutableStateOf("09175550192")
    var userEmail by mutableStateOf("juan.wawa@nasugbu.ph")
    var isPhoneVerified by mutableStateOf(true)
    var homeLat by mutableDoubleStateOf(14.0835)
    var homeLng by mutableDoubleStateOf(120.6214)

    // Topic 8, 9 & 10: Polymorphic User Reference (Abstract User -> Resident/Collector/Manager)
    val activeUser: User
        get() = when (currentUserRole) {
            "Manager" -> Manager(
                userId = "MGR-001",
                name = if (userFullName == "Juan Dela Cruz") "Engr. Maria Santos" else userFullName,
                contactNumber = userPhone,
                email = "menro@nasugbu.gov.ph",
                staffId = "MENRO-2026-01",
                zoneManaged = "All Nasugbu Zones"
            )
            "Collector" -> Collector(
                userId = "COL-004",
                name = if (userFullName == "Juan Dela Cruz") "Kuya Pedro Reyes" else userFullName,
                contactNumber = userPhone,
                email = "truck04@linisnasugbu.ph",
                assignedRouteId = "Poblacion – Coastal Loop",
                vehicleNumber = "Truck #04"
            )
            else -> {
                val brgyName = if (userAddress.contains(",")) {
                    userAddress.substringBefore(",").trim()
                } else {
                    "Brgy. Wawa"
                }
                Resident(
                    userId = "RES-101",
                    name = userFullName,
                    contactNumber = userPhone,
                    email = userEmail,
                    address = userAddress,
                    barangay = brgyName,
                    zone = "Poblacion & Coastal Sector"
                )
            }
        }

    init {
        wasteCollectionService.addCollectionPoint(
            CollectionPoint(
                pointId = "CP-01",
                pointName = "Brgy. Wawa Port Terminal",
                location = Location(
                    barangay = "Brgy. Wawa",
                    zone = "Coastal Sector",
                    fullAddress = "Brgy. Wawa Port Terminal, Nasugbu, Batangas",
                    latitude = 14.0835,
                    longitude = 120.6214
                ),
                acceptedWasteTypes = listOf(WasteType.BIODEGRADABLE),
                isActive = true
            )
        )
    }

    fun registerResidentAccount(name: String, email: String, password: String) {
        registeredAccounts.add(RegisteredAccount(email.trim().lowercase(), password, name.trim()))
    }

    fun loadSession(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        currentUserRole = prefs.getString("role", null)
        isProfileCompleted = prefs.getBoolean("is_profile_completed", false)
        userFullName = prefs.getString("full_name", "Juan Dela Cruz") ?: "Juan Dela Cruz"
        userAddress = prefs.getString("address", "Brgy. Wawa, Nasugbu") ?: "Brgy. Wawa, Nasugbu"
        userPhone = prefs.getString("phone", "09175550192") ?: "09175550192"
        userEmail = prefs.getString("email", "juan.wawa@nasugbu.ph") ?: "juan.wawa@nasugbu.ph"
        isPhoneVerified = prefs.getBoolean("is_phone_verified", true)
    }

    fun saveSession(
        context: Context,
        role: String?,
        profileCompleted: Boolean,
        name: String = userFullName,
        address: String = userAddress,
        phone: String = userPhone,
        email: String = userEmail
    ) {
        currentUserRole = role
        isProfileCompleted = profileCompleted
        userFullName = name
        userAddress = address
        userPhone = phone
        userEmail = email

        val editor = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
        editor.putString("role", role)
        editor.putBoolean("is_profile_completed", profileCompleted)
        editor.putString("full_name", name)
        editor.putString("address", address)
        editor.putString("phone", phone)
        editor.putString("email", email)
        editor.putBoolean("is_phone_verified", isPhoneVerified)
        editor.apply()
    }

    fun clearSession(context: Context) {
        currentUserRole = null
        isProfileCompleted = false
        val editor = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
        editor.clear()
        editor.apply()
    }

    // Shared Tickets with Manager Resolution Note
    val tickets = mutableStateListOf(
        TicketItem(
            id = "REQ-101",
            residentName = "Juan Dela Cruz",
            type = "Bulk Pickup",
            barangay = "Brgy. Wawa",
            description = "Garden trimmings & 2 sacks",
            status = "Approved",
            resolutionNote = "Dispatched Truck #05 for afternoon special collection."
        ),
        TicketItem(
            id = "CMP-102",
            residentName = "Maria Clara",
            type = "Complaint",
            barangay = "Brgy. 5 (Poblacion)",
            description = "Delayed morning collection",
            status = "Completed",
            resolutionNote = "Re-routed Truck #02; missed alley cleared at 10:30 AM."
        )
    )

    val routeStops = mutableStateListOf(
        RouteCheckpoint("STP-1", "Brgy. Wawa Port Terminal", "Coastal Sector", "Medium Load • Biodegradable", "Medium", 1.2, 14.0835, 120.6214, true, "Collected"),
        RouteCheckpoint("STP-2", "Brgy. 5 (Poblacion) Public Market", "Poblacion Zone", "Heavy Load • Mixed Waste", "Heavy", 3.8, 14.0725, 120.6322, false, "Pending"),
        RouteCheckpoint("STP-3", "Brgy. Bucana Coastal Road", "Coastal Sector", "Low Load • Residual", "Low", 2.1, 14.0880, 120.6195, false, "Pending"),
        RouteCheckpoint("STP-4", "Brgy. Pantalan & Talangan Loop", "Poblacion South", "Medium Load • Biodegradable", "Medium", 2.9, 14.0790, 120.6250, false, "Pending"),
        RouteCheckpoint("STP-5", "Nasugbu Sanitary MRF", "Disposal Facility", "Unload & Drop-off", "Low", 5.4, 14.0910, 120.6580, false, "Pending")
    )

    val zoneAssignments = mutableStateListOf(
        ZoneAssignment("Coastal Sector (Wawa – Bucana)", "Truck #04", "Wed / Sat", true),
        ZoneAssignment("Poblacion Commercial (Brgy. 1–12)", "Truck #02", "Tue / Fri", true),
        ZoneAssignment("Pantalan & Talangan Sector", "Truck #01", "Mon / Thu", true)
    )

    val fleetVehicles = mutableStateListOf(
        FleetVehicle("Truck #04", "Kuya Pedro Reyes", "Coastal Sector", 5, "Heavy (85%)"),
        FleetVehicle("Truck #02", "Kuya Ramon Cruz", "Poblacion Zone", 2, "Low (40%)")
    )

    var isFleetBalanced by mutableStateOf(false)
    var fleetBalanceMessage by mutableStateOf("")

    // Topic 2 & 4: Standard for-loop summing encapsulated method getCapacityWeight()
    val activeCapacityPercent: Int
        get() {
            var totalWeight = 0
            for (stop in routeStops) {
                totalWeight += stop.getCapacityWeight()
            }
            return if (totalWeight > 100) 100 else totalWeight
        }

    var currentStopIndex by mutableIntStateOf(1)
    var isRouteOptimized by mutableStateOf(false)
    var savedDistanceText by mutableStateOf("")

    fun submitTicket(residentName: String, type: String, barangay: String, description: String) {
        val prefix = if (type == "Bulk Pickup") "REQ" else "CMP"
        val newId = "$prefix-${103 + tickets.size}"
        tickets.add(
            0,
            TicketItem(
                id = newId,
                residentName = residentName,
                type = type,
                barangay = barangay,
                description = description,
                status = "Pending",
                resolutionNote = "Pending MENRO review and action plan"
            )
        )
    }

    fun processTicket(ticketId: String) {
        for (i in tickets.indices) {
            if (tickets[i].id == ticketId) {
                tickets[i] = tickets[i].copy(
                    status = "Processed",
                    resolutionNote = "Verified by MENRO; preparing truck dispatch solution"
                )
                break
            }
        }
    }

    fun approveTicketAndAssign(ticketId: String, solutionPlan: String = "Dispatched Truck #05 for special pickup today") {
        for (i in tickets.indices) {
            if (tickets[i].id == ticketId) {
                val ticket = tickets[i]
                tickets[i] = ticket.copy(
                    status = "Approved",
                    resolutionNote = solutionPlan
                )
                val insertPos = if (routeStops.size > 0) routeStops.size - 1 else 0
                routeStops.add(
                    insertPos,
                    RouteCheckpoint(
                        id = ticket.id,
                        stopName = "${ticket.type}: ${ticket.barangay}",
                        zone = "Action Plan: $solutionPlan",
                        estimatedLoad = "Low Load • ${ticket.description}",
                        loadLevel = "Low",
                        distanceKm = 1.5,
                        lat = 14.0750,
                        lng = 120.6340,
                        isCompleted = false,
                        collectionStatus = "Pending"
                    )
                )
                break
            }
        }
    }

    fun assignTruckToUncoveredZone(zoneIndex: Int, truckId: String = "Truck #03") {
        if (zoneIndex !in zoneAssignments.indices) return
        val current = zoneAssignments[zoneIndex]
        zoneAssignments[zoneIndex] = current.copy(
            assignedTruck = truckId,
            scheduleDay = "Tue / Fri",
            isCovered = true
        )
    }

    fun balanceFleetWorkload() {
        if (fleetVehicles.size >= 2) {
            fleetVehicles[0] = fleetVehicles[0].copy(stopCount = 3, loadStatus = "Balanced (60%)")
            fleetVehicles[1] = fleetVehicles[1].copy(stopCount = 4, loadStatus = "Balanced (65%)")
            isFleetBalanced = true
            fleetBalanceMessage = "Balanced: Moved 2 stops from Truck #04 to Truck #02"
        }
    }

    fun updateStopStatus(index: Int, newStatus: String, reason: String = "") {
        if (index !in routeStops.indices) return
        val stop = routeStops[index]
        val completed = newStatus == "Collected"
        routeStops[index] = stop.copy(
            isCompleted = completed,
            collectionStatus = newStatus,
            skipReason = if (newStatus == "Rescheduled") reason else ""
        )

        for (i in tickets.indices) {
            if (tickets[i].id == stop.id) {
                val updatedTicketStatus = when (newStatus) {
                    "Collected" -> "Completed"
                    "Rescheduled" -> "Rescheduled ($reason)"
                    else -> "Approved"
                }
                tickets[i] = tickets[i].copy(status = updatedTicketStatus)
                break
            }
        }
    }

    fun toggleStopCompletion(index: Int, completed: Boolean) {
        updateStopStatus(index, if (completed) "Collected" else "Pending")
    }

    fun optimizeNasugbuRoute() {
        val completed = mutableListOf<RouteCheckpoint>()
        val rescheduled = mutableListOf<RouteCheckpoint>()
        val pendingMiddle = mutableListOf<RouteCheckpoint>()
        var finalDrop: RouteCheckpoint? = null

        // Topic 2: Basic for-loop categorization
        for (stop in routeStops) {
            if (stop.zone == "Disposal Facility") {
                finalDrop = stop
            } else if (stop.collectionStatus == "Collected") {
                completed.add(stop)
            } else if (stop.collectionStatus == "Rescheduled") {
                rescheduled.add(stop)
            } else {
                pendingMiddle.add(stop)
            }
        }

        // Topic 2: Basic bubble sort by distanceKm
        for (i in 0 until pendingMiddle.size - 1) {
            for (j in 0 until pendingMiddle.size - i - 1) {
                if (pendingMiddle[j].distanceKm > pendingMiddle[j + 1].distanceKm) {
                    val temp = pendingMiddle[j]
                    pendingMiddle[j] = pendingMiddle[j + 1]
                    pendingMiddle[j + 1] = temp
                }
            }
        }

        routeStops.clear()
        for (item in completed) routeStops.add(item)
        for (item in pendingMiddle) routeStops.add(item)
        for (item in rescheduled) routeStops.add(item)
        if (finalDrop != null && finalDrop.collectionStatus != "Collected") {
            routeStops.add(finalDrop)
        }

        // Topic 7: Collaborate with RouteOptimizerService using standard for-loop
        val domainStops = mutableListOf<RouteStop>()
        for (idx in routeStops.indices) {
            val cp = routeStops[idx]
            domainStops.add(
                RouteStop(
                    stopId = cp.id,
                    routeId = "RT-NASUGBU-01",
                    pointId = cp.id,
                    sequenceNumber = idx + 1,
                    estimatedArrival = "08:${15 + (idx * 15)} AM",
                    isCompleted = cp.isCompleted
                )
            )
        }
        val domainRoute = Route(
            routeId = "RT-NASUGBU-01",
            routeName = "Poblacion – Coastal Loop",
            zone = "Coastal Sector",
            estimatedTotalTime = "2 hrs 15 mins",
            stops = domainStops
        )
        val progressPercent = routeOptimizerService.getRouteProgress(domainRoute).toInt()

        isRouteOptimized = true
        savedDistanceText = "Route Optimized: 14.2 km → 11.6 km (Saved 2.6 km • $progressPercent% Done)"
    }

    fun advanceTruckLocation() {
        if (routeStops.isNotEmpty()) {
            currentStopIndex = (currentStopIndex + 1) % routeStops.size
        }
    }
}