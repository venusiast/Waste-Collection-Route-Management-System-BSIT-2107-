package com.example.linisnasugbu.model

import com.example.linisnasugbu.model.enums.UserRole

class Resident(
    override val userId: String,
    override val name: String,
    override val contactNumber: String,
    override val email: String,
    val address: String,
    val barangay: String,
    val zone: String
) : User(userId, name, contactNumber, email, UserRole.RESIDENT) {

    override fun getFullInfo(): String {
        return super.getFullInfo() + "\nAddress: $address, $barangay\nZone: $zone"
    }

    fun submitRequest() {
        // Logic handled in Service class
    }
}
