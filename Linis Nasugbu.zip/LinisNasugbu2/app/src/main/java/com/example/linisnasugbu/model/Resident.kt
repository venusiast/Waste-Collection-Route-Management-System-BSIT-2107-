package com.example.linisnasugbu.model

import com.example.linisnasugbu.model.enums.UserRole

class Resident(
    userId: String,
    override val name: String,
    contactNumber: String,
    override val email: String,
    val address: String,
    val barangay: String,
    val zone: String
) : User(userId, name, contactNumber, email, UserRole.RESIDENT) {

    override fun getDisplayBadge(): String = "RESIDENT • $barangay"

    override fun getDashboardSummary(): String =
        "Barangay Waste Schedule & Citizen Reporting ($zone)"

    override fun getFullInfo(): String {
        return super.getFullInfo() + "\nAddress: $address, $barangay\nZone: $zone"
    }
}