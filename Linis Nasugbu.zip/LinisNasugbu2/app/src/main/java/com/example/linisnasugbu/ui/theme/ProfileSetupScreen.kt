package com.example.linisnasugbu.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.linisnasugbu.service.LinisNasugbuRepository

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileSetupScreen(
    role: String,
    initialName: String,
    initialEmail: String,
    onCompleteSetup: (name: String, address: String, phone: String, email: String) -> Unit
) {
    val nasugbuBarangays = listOf(
        "Brgy. Wawa, Nasugbu",
        "Brgy. Bucana, Nasugbu",
        "Brgy. 1 (Poblacion), Nasugbu",
        "Brgy. 5 (Poblacion), Nasugbu",
        "Brgy. 10 (Poblacion), Nasugbu",
        "Brgy. Natipuan, Nasugbu",
        "Brgy. Papaya, Nasugbu",
        "Brgy. Looc, Nasugbu",
        "Brgy. Lumbangan, Nasugbu",
        "Brgy. Lian-Nasugbu Boundary"
    )

    var fullName by remember { mutableStateOf(initialName) }
    var selectedBarangay by remember { mutableStateOf(nasugbuBarangays[0]) }
    var streetDetails by remember { mutableStateOf("") }
    var phoneNumber by remember { mutableStateOf("") }
    var email by remember { mutableStateOf(initialEmail) }
    var expanded by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundLight)
            .verticalScroll(rememberScrollState())
    ) {
        // Gradient Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
                .background(NasugbuHeroGradient)
                .padding(horizontal = 24.dp, vertical = 28.dp)
        ) {
            Column {
                Surface(shape = RoundedCornerShape(20.dp), color = SafetyOrange) {
                    Text(
                        text = "STEP 2 OF 2 • ${role.uppercase()} PROFILE",
                        color = SurfaceWhite,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Complete Your Details",
                    color = SurfaceWhite,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Verify your Nasugbu address & contact info for collection alerts.",
                    color = SurfaceWhite.copy(alpha = 0.85f),
                    fontSize = 13.sp
                )
            }
        }

        // Form Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
            elevation = CardDefaults.cardElevation(4.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // 1. Full Name
                OutlinedTextField(
                    value = fullName,
                    onValueChange = { fullName = it; errorMessage = null },
                    label = { Text("Full Name") },
                    placeholder = { Text("e.g. Juan Dela Cruz") },
                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = CoastalTeal) },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                // 2. Nasugbu Barangay Dropdown
                ExposedDropdownMenuBox(
                    expanded = expanded,
                    onExpandedChange = { expanded = !expanded }
                ) {
                    OutlinedTextField(
                        value = selectedBarangay,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Barangay (Nasugbu, Batangas)") },
                        leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null, tint = SafetyOrange) },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false }
                    ) {
                        nasugbuBarangays.forEach { brgy ->
                            DropdownMenuItem(
                                text = { Text(brgy) },
                                onClick = {
                                    selectedBarangay = brgy
                                    expanded = false
                                }
                            )
                        }
                    }
                }

                // Street / House Number
                OutlinedTextField(
                    value = streetDetails,
                    onValueChange = { streetDetails = it },
                    label = { Text("Street / Sitio / Landmark (Optional)") },
                    placeholder = { Text("e.g. Purok 3, near Wawa Elementary") },
                    leadingIcon = { Icon(Icons.Default.Home, contentDescription = null, tint = CoastalTeal) },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                // 3. Phone Number
                OutlinedTextField(
                    value = phoneNumber,
                    onValueChange = { phoneNumber = it; errorMessage = null },
                    label = { Text("Mobile Number") },
                    placeholder = { Text("09XX-XXX-XXXX") },
                    leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = EcoGreen) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                // 4. Email Address
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it; errorMessage = null },
                    label = { Text("Email Address") },
                    placeholder = { Text("name@email.com") },
                    leadingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = CoastalNavy) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                if (errorMessage != null) {
                    Text(
                        text = errorMessage!!,
                        color = AlertRed,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Button(
                    onClick = {
                        when {
                            fullName.isBlank() -> errorMessage = "Please enter your full name."
                            phoneNumber.isBlank() -> errorMessage = "Please enter your mobile number."
                            email.isBlank() || !email.contains("@") -> errorMessage = "Please enter a valid email address."
                            else -> {
                                val fullAddress = if (streetDetails.isNotBlank()) {
                                    "$streetDetails, $selectedBarangay"
                                } else {
                                    selectedBarangay
                                }
                                LinisNasugbuRepository.userFullName = fullName.trim()
                                LinisNasugbuRepository.userAddress = fullAddress
                                LinisNasugbuRepository.userPhone = phoneNumber.trim()
                                LinisNasugbuRepository.userEmail = email.trim()

                                onCompleteSetup(fullName.trim(), fullAddress, phoneNumber.trim(), email.trim())
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EcoGreen),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                ) {
                    Text("Save & Enter Dashboard", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = SurfaceWhite)
                }
            }
        }
    }
}