package com.example.linisnasugbu.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.linisnasugbu.service.LinisNasugbuRepository

data class NasugbuBarangayDirectory(
    val name: String,
    val lat: Double,
    val lng: Double
)

val nasugbuBarangayDirectory = listOf(
    NasugbuBarangayDirectory("Brgy. 1 (Poblacion)", 14.0695, 120.6310),
    NasugbuBarangayDirectory("Brgy. 2 (Poblacion)", 14.0702, 120.6320),
    NasugbuBarangayDirectory("Brgy. 3 (Poblacion)", 14.0710, 120.6331),
    NasugbuBarangayDirectory("Brgy. 4 (Poblacion)", 14.0718, 120.6340),
    NasugbuBarangayDirectory("Brgy. 5 (Poblacion)", 14.0725, 120.6322),
    NasugbuBarangayDirectory("Brgy. 6 (Poblacion)", 14.0732, 120.6315),
    NasugbuBarangayDirectory("Brgy. 7 (Poblacion)", 14.0740, 120.6328),
    NasugbuBarangayDirectory("Brgy. 8 (Poblacion)", 14.0748, 120.6338),
    NasugbuBarangayDirectory("Brgy. 9 (Poblacion)", 14.0755, 120.6345),
    NasugbuBarangayDirectory("Brgy. 10 (Poblacion)", 14.0762, 120.6352),
    NasugbuBarangayDirectory("Brgy. 11 (Poblacion)", 14.0768, 120.6360),
    NasugbuBarangayDirectory("Brgy. 12 (Poblacion)", 14.0775, 120.6368),
    NasugbuBarangayDirectory("Brgy. Bucana", 14.0880, 120.6195),
    NasugbuBarangayDirectory("Brgy. Talangan", 14.0660, 120.6410),
    NasugbuBarangayDirectory("Brgy. Pantalan", 14.0790, 120.6250),
    NasugbuBarangayDirectory("Brgy. Wawa", 14.0835, 120.6214)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileSetupScreen(
    role: String,
    initialName: String,
    initialEmail: String,
    onCompleteSetup: (name: String, address: String, phone: String, email: String) -> Unit
) {
    var fullName by remember { mutableStateOf(initialName) }
    var searchQuery by remember { mutableStateOf("Brgy. Wawa") }
    var selectedDirectory by remember { mutableStateOf(nasugbuBarangayDirectory[nasugbuBarangayDirectory.size - 1]) }
    var streetDetails by remember { mutableStateOf("") }
    var phoneNumber by remember { mutableStateOf("") }
    var isPhoneVerified by remember { mutableStateOf(false) }
    var otpSent by remember { mutableStateOf(false) }
    var otpInput by remember { mutableStateOf("") }
    var email by remember { mutableStateOf(initialEmail) }
    var expanded by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    // Topic 2: Basic for-loop for Barangay Directory search
    val filteredDirectory = mutableListOf<NasugbuBarangayDirectory>()
    for (item in nasugbuBarangayDirectory) {
        if (item.name.lowercase().contains(searchQuery.lowercase())) {
            filteredDirectory.add(item)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundLight)
            .verticalScroll(rememberScrollState())
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
                .background(NasugbuHeroGradient)
                .padding(horizontal = 24.dp, vertical = 28.dp)
        ) {
            Column {
                Surface(shape = RoundedCornerShape(20.dp), color = SafetyOrange) {
                    Text(
                        text = "STEP 2 OF 2 • ${role.uppercase()} PROFILE",
                        color = SurfaceWhite,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                Text("Complete & Verify Details", color = SurfaceWhite, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text(
                    text = "Select your Nasugbu barangay directory to pin your GPS pickup location.",
                    color = SurfaceWhite.copy(alpha = 0.85f),
                    fontSize = 13.sp
                )
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth().padding(20.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
            elevation = CardDefaults.cardElevation(4.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                OutlinedTextField(
                    value = fullName,
                    onValueChange = { fullName = it; errorMessage = null },
                    label = { Text("Full Name") },
                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = CoastalTeal) },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                // Searchable Nasugbu Barangay Directory
                ExposedDropdownMenuBox(
                    expanded = expanded,
                    onExpandedChange = { expanded = !expanded }
                ) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = {
                            searchQuery = it
                            expanded = true
                        },
                        label = { Text("Search Nasugbu Barangay Directory") },
                        leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null, tint = SafetyOrange) },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = expanded && filteredDirectory.isNotEmpty(),
                        onDismissRequest = { expanded = false },
                        modifier = Modifier.heightIn(max = 200.dp)
                    ) {
                        for (item in filteredDirectory) {
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text("${item.name}, Nasugbu", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text("GPS Pin: ${item.lat}° N, ${item.lng}° E", fontSize = 11.sp, color = TextSecondary)
                                    }
                                },
                                onClick = {
                                    selectedDirectory = item
                                    searchQuery = item.name
                                    expanded = false
                                }
                            )
                        }
                    }
                }

                // GPS Pin Confirmation Badge
                Surface(shape = RoundedCornerShape(10.dp), color = MintAccent, modifier = Modifier.fillMaxWidth()) {
                    Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EcoGreen, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "GPS Home Pin Locked: ${selectedDirectory.name} (${selectedDirectory.lat}, ${selectedDirectory.lng})",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = EcoGreen
                        )
                    }
                }

                OutlinedTextField(
                    value = streetDetails,
                    onValueChange = { streetDetails = it },
                    label = { Text("House No. / Street / Landmark (Optional)") },
                    leadingIcon = { Icon(Icons.Default.Home, contentDescription = null, tint = CoastalTeal) },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                // Digits-Only 11-Digit Mobile Number + Verification Lock
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = phoneNumber,
                        onValueChange = { input ->
                            if (!isPhoneVerified) {
                                var digitsOnly = ""
                                for (ch in input) {
                                    if (ch in '0'..'9' && digitsOnly.length < 11) {
                                        digitsOnly += ch
                                    }
                                }
                                phoneNumber = digitsOnly
                                errorMessage = null
                            }
                        },
                        enabled = !isPhoneVerified,
                        label = { Text(if (isPhoneVerified) "Verified Mobile (Locked)" else "Mobile (11 digits)") },
                        placeholder = { Text("09XXXXXXXXX") },
                        leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = EcoGreen) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f)
                    )

                    if (!isPhoneVerified) {
                        Button(
                            onClick = {
                                if (phoneNumber.length == 11 && phoneNumber.startsWith("09")) {
                                    otpSent = true
                                    errorMessage = null
                                } else {
                                    errorMessage = "Enter a valid 11-digit number starting with 09."
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CoastalNavy),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.height(54.dp)
                        ) {
                            Text("Verify", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                if (otpSent && !isPhoneVerified) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = otpInput,
                            onValueChange = { input ->
                                var digits = ""
                                for (ch in input) {
                                    if (ch in '0'..'9' && digits.length < 4) {
                                        digits += ch
                                    }
                                }
                                otpInput = digits
                            },
                            label = { Text("Enter 4-Digit OTP (e.g. 1234)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        )
                        Button(
                            onClick = {
                                if (otpInput.length == 4) {
                                    isPhoneVerified = true
                                    otpSent = false
                                    errorMessage = null
                                } else {
                                    errorMessage = "Enter the 4-digit verification code."
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = EcoGreen),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Confirm", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it; errorMessage = null },
                    label = { Text("Email Address") },
                    leadingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = CoastalNavy) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                if (errorMessage != null) {
                    Text(errorMessage!!, color = AlertRed, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                }

                Button(
                    onClick = {
                        when {
                            fullName.isBlank() -> errorMessage = "Please enter your full name."
                            phoneNumber.length != 11 || !phoneNumber.startsWith("09") ->
                                errorMessage = "Mobile number must be 11 digits starting with 09."
                            !isPhoneVerified ->
                                errorMessage = "Please verify your mobile number first."
                            email.isBlank() || !email.contains("@") ->
                                errorMessage = "Please enter a valid email address."
                            else -> {
                                val fullAddress = if (streetDetails.isNotBlank()) {
                                    "${streetDetails.trim()}, ${selectedDirectory.name}, Nasugbu"
                                } else {
                                    "${selectedDirectory.name}, Nasugbu"
                                }
                                LinisNasugbuRepository.userFullName = fullName.trim()
                                LinisNasugbuRepository.userAddress = fullAddress
                                LinisNasugbuRepository.userPhone = phoneNumber
                                LinisNasugbuRepository.userEmail = email.trim()
                                LinisNasugbuRepository.isPhoneVerified = true
                                LinisNasugbuRepository.homeLat = selectedDirectory.lat
                                LinisNasugbuRepository.homeLng = selectedDirectory.lng

                                onCompleteSetup(fullName.trim(), fullAddress, phoneNumber, email.trim())
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EcoGreen),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) {
                    Text("Save & Enter Dashboard", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = SurfaceWhite)
                }
            }
        }
    }
}