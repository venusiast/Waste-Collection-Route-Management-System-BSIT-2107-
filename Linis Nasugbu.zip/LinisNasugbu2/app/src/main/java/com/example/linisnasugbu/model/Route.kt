package com.example.linisnasugbu.model

import com.example.linisnasugbu.model.enums.RouteStatus

data class Route(
    val routeId: String,
    val routeName: String,
    val zone: String,
    val assignedCollectorId: String? = null,
    val estimatedTotalTime: String,
    val status: RouteStatus = RouteStatus.PENDING,
    val stops: MutableList<RouteStop> = mutableListOf()
) {
    fun addStop(stop: RouteStop) {
        stops.add(stop)
    }

    fun getOrderedStops(): List<RouteStop> {
        return stops.sortedBy { it.sequenceNumber }
    }
}
