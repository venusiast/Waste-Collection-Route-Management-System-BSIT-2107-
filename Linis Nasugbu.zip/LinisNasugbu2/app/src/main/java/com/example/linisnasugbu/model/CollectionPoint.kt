package com.example.linisnasugbu.model

import com.example.linisnasugbu.model.enums.WasteType

data class CollectionPoint(
    val pointId: String,
    val location: Location,
    val pointName: String,
    val acceptedWasteTypes: List<WasteType>,
    val notes: String = "",
    val isActive: Boolean = true
)