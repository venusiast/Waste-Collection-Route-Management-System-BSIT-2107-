package com.example.linisnasugbu.model

import com.example.linisnasugbu.model.enums.UserRole

class Collector(
    userId: String,
    override val name: String,
    contactNumber: String,
    override val email: String,
    val assignedRouteId: String? = null,
    val vehicleNumber: String
) : User(userId, name, contactNumber, email, UserRole.COLLECTOR) {

    override fun getDisplayBadge(): String = "FIELD COLLECTOR • $vehicleNumber"

    override fun getDashboardSummary(): String =
        "Active Route: ${assignedRouteId ?: "Poblacion – Coastal Loop"}"

    override fun getFullInfo(): String {
        val routeText = assignedRouteId ?: "No route assigned"
        return super.getFullInfo() + "\nVehicle: $vehicleNumber\nAssigned Route: $routeText"
    }
}