package com.example.linisnasugbu.model

import com.example.linisnasugbu.model.enums.UserRole

class Collector(
    override val userId: String,
    override val name: String,
    override val contactNumber: String,
    override val email: String,
    val assignedRouteId: String? = null,
    val vehicleNumber: String
) : User(userId, name, contactNumber, email, UserRole.COLLECTOR) {

    override fun getFullInfo(): String {
        val routeText = assignedRouteId ?: "No route assigned"
        return super.getFullInfo() + "\nVehicle: $vehicleNumber\nAssigned Route: $routeText"
    }

    fun markStopAsCompleted() {
        // Logic handled in Service class
    }
}
