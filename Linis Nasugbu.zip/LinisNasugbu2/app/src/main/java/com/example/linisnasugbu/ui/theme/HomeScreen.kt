package com.example.linisnasugbu.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.linisnasugbu.service.LinisNasugbuRepository

data class NasugbuScheduleItem(
    val barangay: String,
    val wasteType: String,
    val dayAndTime: String,
    val status: String,
    val badgeColor: Color,
    val badgeBg: Color
)

@Composable
fun HomeScreen(
    userName: String = "Juan Dela Cruz",
    barangay: String = "Brgy. Wawa, Nasugbu",
    onNavigateTab: (Int) -> Unit = {}
) {
    var showSegregationGuide by remember { mutableStateOf(false) }
    var modalType by remember { mutableStateOf<String?>(null) }
    val activeStop = LinisNasugbuRepository.routeStops.getOrNull(LinisNasugbuRepository.currentStopIndex)

    val schedules = listOf(
        NasugbuScheduleItem("Brgy. Wawa & Bucana", "Biodegradable (Nabubulok)", "Mon & Thu • 6:00 AM", "Truck Nearby", EcoGreen, MintAccent),
        NasugbuScheduleItem("Poblacion (Brgy. 1 - 12)", "Recyclable & Plastic", "Tue & Fri • 7:00 AM", "Scheduled", SafetyOrange, SoftOrangeBg),
        NasugbuScheduleItem("Brgy. Natipuan & Papaya", "Coastal & Residual Waste", "Wed & Sat • 6:30 AM", "Scheduled", CoastalTeal, Color(0xFFE0F2F1))
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundLight),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        // 1. GRADIENT HERO HEADER + FLOATING LIVE TRACKER CARD
        item {
            Box(modifier = Modifier.fillMaxWidth()) {
                // Gradient Background Banner
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(195.dp)
                        .clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
                        .background(NasugbuHeroGradient)
                        .padding(horizontal = 20.dp, vertical = 20.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Default.LocationOn,
                                    contentDescription = null,
                                    tint = SafetyOrange,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = barangay,
                                    color = SurfaceWhite.copy(alpha = 0.9f),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }

                            Surface(
                                shape = CircleShape,
                                color = SurfaceWhite.copy(alpha = 0.15f),
                                modifier = Modifier.size(38.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        Icons.Default.Notifications,
                                        contentDescription = "Notifications",
                                        tint = SurfaceWhite,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Text(
                            text = "Mabuhay, $userName!",
                            color = SurfaceWhite,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = (-0.5).sp
                        )
                        Text(
                            text = "Keep Nasugbu clean & coastal-safe today.",
                            color = SurfaceWhite.copy(alpha = 0.8f),
                            fontSize = 13.sp
                        )
                    }
                }

                // Floating Live Truck Tracker Card (Grab/Foodpanda Style)
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp)
                        .padding(top = 135.dp)
                        .clickable { onNavigateTab(1) },
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                    elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = MintAccent,
                                    modifier = Modifier.size(40.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(Icons.Default.Place, contentDescription = null, tint = EcoGreen)
                                    }
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        "Truck #04 is ${(LinisNasugbuRepository.currentStopIndex + 1) * 4} mins away",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = TextPrimary
                                    )
                                    Text(
                                        "Current: ${activeStop?.stopName ?: "Poblacion Loop"}",
                                        fontSize = 12.sp,
                                        color = TextSecondary
                                    )
                                }
                            }
                            Icon(Icons.Default.KeyboardArrowRight, contentDescription = null, tint = TextSecondary)
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        LinearProgressIndicator(
                            progress = { 0.72f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(CircleShape),
                            color = EcoGreen,
                            trackColor = MintAccent
                        )
                    }
                }
            }
        }

        // 2. QUICK SERVICES GRID (4-Icon Action Bar)
        item {
            Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 18.dp)) {
                Text(
                    "Quick Services",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    QuickActionTile("Live Map", Icons.Default.LocationOn, EcoGreen, MintAccent) { onNavigateTab(1) }
                    QuickActionTile("Bulk Pickup", Icons.Default.AddCircle, SafetyOrange, SoftOrangeBg) { modalType = "Bulk Pickup" }
                    QuickActionTile("Report Issue", Icons.Default.Warning, AlertRed, SoftRedBg) { modalType = "Complaint" }
                    QuickActionTile("Segregation", Icons.Default.Info, CoastalTeal, Color(0xFFE0F2F1)) { showSegregationGuide = true }
                }
            }
        }

        // 3. SCHEDULE SECTION HEADER
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Collection Schedules",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = TextPrimary
                )
                Text(
                    "Nasugbu Zone A",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = EcoGreen
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
        }

        // 4. MODERN SCHEDULE CARDS
        items(schedules) { item ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 6.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Row(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            item.barangay,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            item.wasteType,
                            fontSize = 13.sp,
                            color = TextSecondary
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.DateRange,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp),
                                tint = CoastalTeal
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                item.dayAndTime,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                color = TextPrimary
                            )
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = item.badgeBg
                    ) {
                        Text(
                            text = item.status,
                            color = item.badgeColor,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }
                }
            }
        }
    }

    if (showSegregationGuide) {
        SegregationGuideModal(onDismiss = { showSegregationGuide = false })
    }

    if (modalType != null) {
        RequestComplaintModal(
            type = modalType!!,
            onDismiss = { modalType = null },
            onSubmit = { brgy, desc ->
                LinisNasugbuRepository.submitTicket(userName, modalType!!, brgy, desc)
                modalType = null
                onNavigateTab(2)
            }
        )
    }
}

@Composable
fun QuickActionTile(
    label: String,
    icon: ImageVector,
    tint: Color,
    bgColor: Color,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .width(76.dp)
            .clickable { onClick() }
    ) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = bgColor,
            modifier = Modifier.size(56.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(26.dp))
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = label,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            color = TextPrimary,
            maxLines = 1
        )
    }
}