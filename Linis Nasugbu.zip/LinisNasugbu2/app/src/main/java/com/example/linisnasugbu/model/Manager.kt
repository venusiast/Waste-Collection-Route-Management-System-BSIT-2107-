package com.example.linisnasugbu.model

import com.example.linisnasugbu.model.enums.UserRole

class Manager(
    userId: String,
    override val name: String,
    contactNumber: String,
    override val email: String,
    val staffId: String,
    val zoneManaged: String
) : User(userId, name, contactNumber, email, UserRole.MANAGER) {

    override fun getDisplayBadge(): String = "MUNICIPAL OPERATIONS • $zoneManaged"

    override fun getDashboardSummary(): String =
        "Nasugbu Fleet, Zones & Dispatch Control"

    override fun getFullInfo(): String {
        return super.getFullInfo() + "\nStaff ID: $staffId\nManages Zone: $zoneManaged"
    }
}