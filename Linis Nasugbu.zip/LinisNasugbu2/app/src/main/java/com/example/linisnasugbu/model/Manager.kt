package com.example.linisnasugbu.model

import com.example.linisnasugbu.model.enums.UserRole

class Manager(
    override val userId: String,
    override val name: String,
    override val contactNumber: String,
    override val email: String,
    val staffId: String,
    val zoneManaged: String
) : User(userId, name, contactNumber, email, UserRole.MANAGER) {

    override fun getFullInfo(): String {
        return super.getFullInfo() + "\nStaff ID: $staffId\nManages Zone: $zoneManaged"
    }
}
