package com.example.linisnasugbu.ui.theme

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.linisnasugbu.R
import com.example.linisnasugbu.model.Collector
import com.example.linisnasugbu.model.Manager
import com.example.linisnasugbu.model.Resident
import com.example.linisnasugbu.service.LinisNasugbuRepository

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    role: String,
    userName: String = "Juan Dela Cruz",
    onLogout: () -> Unit
) {
    val currentUser = LinisNasugbuRepository.activeUser
    var isEditing by remember { mutableStateOf(false) }
    var editedName by remember { mutableStateOf(LinisNasugbuRepository.userFullName) }
    var editedAddress by remember { mutableStateOf(LinisNasugbuRepository.userAddress) }
    var selectedDirectory by remember { mutableStateOf(nasugbuBarangayDirectory[nasugbuBarangayDirectory.size - 1]) }
    var brgyMenuExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundLight)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Gradient Profile Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
                .background(NasugbuHeroGradient)
                .padding(vertical = 28.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Surface(shape = CircleShape, color = SurfaceWhite, modifier = Modifier.size(84.dp)) {
                    Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(10.dp)) {
                        Image(
                            painter = painterResource(id = R.drawable.ic_launcher_foreground),
                            contentDescription = "Profile Avatar",
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
                Text(currentUser.name, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = SurfaceWhite)
                Spacer(modifier = Modifier.height(4.dp))
                Surface(shape = RoundedCornerShape(20.dp), color = SafetyOrange) {
                    Text(
                        text = currentUser.getDisplayBadge(),
                        color = SurfaceWhite,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                    )
                }
            }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Account Information", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = CoastalNavy)
                        TextButton(onClick = { isEditing = !isEditing }) {
                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (isEditing) "Cancel" else "Edit Profile", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    if (isEditing) {
                        OutlinedTextField(
                            value = editedName,
                            onValueChange = { editedName = it },
                            label = { Text("Full Name") },
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        )

                        ExposedDropdownMenuBox(
                            expanded = brgyMenuExpanded,
                            onExpandedChange = { brgyMenuExpanded = !brgyMenuExpanded }
                        ) {
                            OutlinedTextField(
                                value = editedAddress,
                                onValueChange = { editedAddress = it },
                                label = { Text("Nasugbu Barangay / Address") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = brgyMenuExpanded) },
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.menuAnchor().fillMaxWidth()
                            )
                            ExposedDropdownMenu(
                                expanded = brgyMenuExpanded,
                                onDismissRequest = { brgyMenuExpanded = false },
                                modifier = Modifier.heightIn(max = 200.dp)
                            ) {
                                for (dir in nasugbuBarangayDirectory) {
                                    DropdownMenuItem(
                                        text = { Text("${dir.name}, Nasugbu") },
                                        onClick = {
                                            selectedDirectory = dir
                                            editedAddress = "${dir.name}, Nasugbu"
                                            brgyMenuExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        // Verified Mobile Number stays locked & non-editable
                        OutlinedTextField(
                            value = currentUser.contactNumber,
                            onValueChange = {},
                            enabled = false,
                            label = { Text("Verified Mobile Number (Locked)") },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Button(
                            onClick = {
                                if (editedName.isNotBlank() && editedAddress.isNotBlank()) {
                                    LinisNasugbuRepository.userFullName = editedName.trim()
                                    LinisNasugbuRepository.userAddress = editedAddress.trim()
                                    LinisNasugbuRepository.homeLat = selectedDirectory.lat
                                    LinisNasugbuRepository.homeLng = selectedDirectory.lng
                                    isEditing = false
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = EcoGreen),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Save Updated Profile", fontWeight = FontWeight.Bold)
                        }
                    } else {
                        ProfileDetailRow("Full Name", currentUser.name)
                        HorizontalDivider(color = BorderLight)
                        ProfileDetailRow("Entity ID", currentUser.entityId)
                        HorizontalDivider(color = BorderLight)
                        ProfileDetailRow("Mobile (Verified)", currentUser.contactNumber)
                        HorizontalDivider(color = BorderLight)
                        ProfileDetailRow("Email Address", currentUser.email)
                        HorizontalDivider(color = BorderLight)
                        ProfileDetailRow("GPS Home Pin", "${LinisNasugbuRepository.homeLat}° N, ${LinisNasugbuRepository.homeLng}° E")
                        HorizontalDivider(color = BorderLight)

                        when (currentUser) {
                            is Collector -> {
                                ProfileDetailRow("Assigned Vehicle", currentUser.vehicleNumber)
                            }
                            is Manager -> {
                                ProfileDetailRow("MENRO Staff ID", currentUser.staffId)
                            }
                            is Resident -> {
                                ProfileDetailRow("Current Address", currentUser.address)
                            }
                        }
                    }
                }
            }

            Button(
                onClick = onLogout,
                colors = ButtonDefaults.buttonColors(containerColor = AlertRed),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(50.dp)
            ) {
                Text("Sign Out", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = SurfaceWhite)
            }
        }
    }
}

@Composable
private fun ProfileDetailRow(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, fontSize = 13.sp, color = TextSecondary)
        Text(value, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
    }
}