package com.example.linisnasugbu.ui.theme

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.linisnasugbu.R
import com.example.linisnasugbu.service.LinisNasugbuRepository

@Composable
fun ProfileScreen(
    role: String,
    userName: String = "Juan Dela Cruz",
    onLogout: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundLight),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Gradient Profile Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
                .background(NasugbuHeroGradient)
                .padding(vertical = 28.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Surface(shape = CircleShape, color = SurfaceWhite, modifier = Modifier.size(84.dp)) {
                    Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(10.dp)) {
                        Image(
                            painter = painterResource(id = R.drawable.ic_launcher_foreground),
                            contentDescription = "Profile Avatar",
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
                Text(userName, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = SurfaceWhite)
                Spacer(modifier = Modifier.height(4.dp))
                Surface(shape = RoundedCornerShape(20.dp), color = SafetyOrange) {
                    Text(
                        text = role.uppercase(),
                        color = SurfaceWhite,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                    )
                }
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    ProfileDetailRow("Full Name", LinisNasugbuRepository.userFullName)
                    HorizontalDivider(color = BorderLight)
                    ProfileDetailRow("Nasugbu Address", LinisNasugbuRepository.userAddress)
                    HorizontalDivider(color = BorderLight)
                    ProfileDetailRow("Mobile Number", LinisNasugbuRepository.userPhone)
                    HorizontalDivider(color = BorderLight)
                    ProfileDetailRow("Email Address", LinisNasugbuRepository.userEmail)
                    HorizontalDivider(color = BorderLight)
                    ProfileDetailRow(
                        label = if (role == "Collector") "Assigned Vehicle" else "Account ID",
                        value = when (role) {
                            "Collector" -> "Dump Truck #04 (Plate: NGB-402)"
                            "Manager" -> "MENRO-ADM-01"
                            else -> "RES-NSG-2026-089"
                        }
                    )
                }
            }

            Button(
                onClick = onLogout,
                colors = ButtonDefaults.buttonColors(containerColor = AlertRed),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(50.dp)
            ) {
                Text("Sign Out", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = SurfaceWhite)
            }
        }
    }
}

@Composable
private fun ProfileDetailRow(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, fontSize = 13.sp, color = TextSecondary)
        Text(value, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
    }
}