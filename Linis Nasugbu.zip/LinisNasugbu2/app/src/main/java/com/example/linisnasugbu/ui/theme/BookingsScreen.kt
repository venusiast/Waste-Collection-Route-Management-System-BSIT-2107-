package com.example.linisnasugbu.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.linisnasugbu.model.Resident
import com.example.linisnasugbu.service.LinisNasugbuRepository
import com.example.linisnasugbu.service.TicketItem

@Composable
fun BookingsScreen(
    role: String = "Resident",
    userName: String = "Juan Dela Cruz"
) {
    var modalType by remember { mutableStateOf<String?>(null) }
    var selectedFilter by remember { mutableStateOf("All") }
    var approvingTicketId by remember { mutableStateOf<String?>(null) }
    var selectedSolutionPlan by remember { mutableStateOf("Dispatched Truck #05 for immediate special pickup today") }
    val filters = listOf("All", "Pending", "Processed", "Approved", "Completed", "Rescheduled")

    // Topic 2: Basic for-loop filtering instead of .filter { }
    val filteredTickets = mutableListOf<TicketItem>()
    for (ticket in LinisNasugbuRepository.tickets) {
        val matches = when (selectedFilter) {
            "All" -> true
            "Rescheduled" -> ticket.status.startsWith("Rescheduled")
            else -> ticket.status == selectedFilter
        }
        if (matches) {
            filteredTickets.add(ticket)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundLight)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp))
                .background(NasugbuHeroGradient)
                .padding(20.dp)
        ) {
            Column {
                Text(
                    text = if (role == "Manager") "Dispatch & Ticket Approvals" else "Requests & Reports",
                    color = SurfaceWhite,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = if (role == "Manager")
                        "Process & assign MENRO resolution plans for collectors"
                    else
                        "Track your requests and view MENRO resolution plans",
                    color = SurfaceWhite.copy(alpha = 0.85f),
                    fontSize = 12.sp
                )
            }
        }

        Column(modifier = Modifier.padding(16.dp)) {
            if (role == "Resident") {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = { modalType = "Bulk Pickup" },
                        colors = ButtonDefaults.buttonColors(containerColor = EcoGreen),
                        modifier = Modifier.weight(1f).height(46.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Bulk Pickup", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { modalType = "Complaint" },
                        colors = ButtonDefaults.buttonColors(containerColor = SafetyOrange),
                        modifier = Modifier.weight(1f).height(46.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Report Issue", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
            ) {
                for (filter in filters) {
                    var count = 0
                    for (t in LinisNasugbuRepository.tickets) {
                        if (filter == "All") {
                            count++
                        } else if (filter == "Rescheduled" && t.status.startsWith("Rescheduled")) {
                            count++
                        } else if (t.status == filter) {
                            count++
                        }
                    }
                    FilterChip(
                        selected = selectedFilter == filter,
                        onClick = { selectedFilter = filter },
                        label = { Text("$filter ($count)", fontSize = 11.sp) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 110.dp)
            ) {
                items(filteredTickets, key = { it.id }) { ticket ->
                    val isRescheduled = ticket.status.startsWith("Rescheduled")
                    val (statusColor, statusBg) = when {
                        ticket.status == "Completed" -> EcoGreen to MintAccent
                        ticket.status == "Approved" -> CoastalTeal to Color(0xFFE0F2F1)
                        ticket.status == "Processed" -> CoastalNavy to Color(0xFFE3F2FD)
                        isRescheduled -> AlertRed to SoftRedBg
                        else -> SafetyOrange to SoftOrangeBg
                    }

                    Card(
                        colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                        shape = RoundedCornerShape(16.dp),
                        elevation = CardDefaults.cardElevation(2.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "${ticket.id} • ${ticket.type}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = if (ticket.type == "Bulk Pickup") EcoGreen else AlertRed
                                )
                                Surface(shape = RoundedCornerShape(20.dp), color = statusBg) {
                                    Text(
                                        text = if (isRescheduled) "RESCHEDULED" else ticket.status.uppercase(),
                                        color = statusColor,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Text(ticket.barangay, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = TextPrimary)
                            Text("By: ${ticket.residentName}", fontSize = 12.sp, color = TextSecondary)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(ticket.description, fontSize = 13.sp, color = TextPrimary)

                            // Shared MENRO Resolution / Action Plan visible to Resident, Collector, & Manager
                            Spacer(modifier = Modifier.height(8.dp))
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = MintAccent,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "MENRO Action Plan: ${ticket.resolutionNote}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = EcoGreen,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }

                            if (isRescheduled) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "⚠ ${ticket.status}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = AlertRed
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))
                            TicketStatusStepper(currentStatus = ticket.status)

                            if (role == "Manager") {
                                when (ticket.status) {
                                    "Pending" -> {
                                        Spacer(modifier = Modifier.height(12.dp))
                                        Button(
                                            onClick = { LinisNasugbuRepository.processTicket(ticket.id) },
                                            colors = ButtonDefaults.buttonColors(containerColor = CoastalNavy),
                                            shape = RoundedCornerShape(10.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Mark as Processed (Verify)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                    "Processed" -> {
                                        Spacer(modifier = Modifier.height(12.dp))
                                        Button(
                                            onClick = { approvingTicketId = ticket.id },
                                            colors = ButtonDefaults.buttonColors(containerColor = EcoGreen),
                                            shape = RoundedCornerShape(10.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Approve & Set Resolution Plan", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Manager Solution Dialog (Visible to both Resident and Collector after approval)
    if (approvingTicketId != null) {
        val presetSolutions = listOf(
            "Dispatched Truck #05 for immediate special pickup today",
            "Assigned Truck #04 backup sweep at 2:00 PM",
            "Scheduled priority morning pickup tomorrow at 6:30 AM"
        )
        AlertDialog(
            onDismissRequest = { approvingTicketId = null },
            shape = RoundedCornerShape(20.dp),
            title = { Text("Assign MENRO Resolution Plan", fontWeight = FontWeight.Bold, color = CoastalNavy) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Select or customize the action plan so the Resident and Collector are informed:",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                    for (option in presetSolutions) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(
                                selected = selectedSolutionPlan == option,
                                onClick = { selectedSolutionPlan = option }
                            )
                            Text(option, fontSize = 12.sp, color = TextPrimary)
                        }
                    }
                    OutlinedTextField(
                        value = selectedSolutionPlan,
                        onValueChange = { selectedSolutionPlan = it },
                        label = { Text("Resolution Message") },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        LinisNasugbuRepository.approveTicketAndAssign(approvingTicketId!!, selectedSolutionPlan)
                        approvingTicketId = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EcoGreen)
                ) {
                    Text("Approve & Dispatch", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { approvingTicketId = null }) { Text("Cancel") }
            }
        )
    }

    if (modalType != null) {
        RequestComplaintModal(
            type = modalType!!,
            onDismiss = { modalType = null },
            onSubmit = { brgy, desc ->
                LinisNasugbuRepository.submitTicket(LinisNasugbuRepository.activeUser.name, modalType!!, brgy, desc)
                modalType = null
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RequestComplaintModal(
    type: String,
    onDismiss: () -> Unit,
    onSubmit: (barangay: String, description: String) -> Unit
) {
    val barangays = listOf(
        "Brgy. 1 (Poblacion)",
        "Brgy. 2 (Poblacion)",
        "Brgy. 3 (Poblacion)",
        "Brgy. 4 (Poblacion)",
        "Brgy. 5 (Poblacion)",
        "Brgy. 6 (Poblacion)",
        "Brgy. 7 (Poblacion)",
        "Brgy. 8 (Poblacion)",
        "Brgy. 9 (Poblacion)",
        "Brgy. 10 (Poblacion)",
        "Brgy. 11 (Poblacion)",
        "Brgy. 12 (Poblacion)",
        "Brgy. Bucana",
        "Brgy. Talangan",
        "Brgy. Pantalan",
        "Brgy. Wawa"
    )

    val complaintCategories = listOf(
        "Missed / Uncollected Garbage",
        "Delayed Collection Schedule",
        "Uncollected Roadside Pile",
        "Overflowing Public Bin"
    )
    val pickupCategories = listOf(
        "Garden / Tree Trimmings",
        "Old Furniture / Appliances",
        "Construction / Renovation Debris",
        "Event / Commercial Bulk Waste"
    )

    val currentUser = LinisNasugbuRepository.activeUser
    var defaultBrgy = "Brgy. Wawa"
    if (currentUser is Resident) {
        for (b in barangays) {
            if (currentUser.barangay.lowercase().contains(b.lowercase())) {
                defaultBrgy = b
                break
            }
        }
    }

    val categories = if (type == "Complaint") complaintCategories else pickupCategories
    var selectedBarangay by remember { mutableStateOf(defaultBrgy) }
    var barangayDropdownExpanded by remember { mutableStateOf(false) }

    var selectedCategory by remember { mutableStateOf(categories[0]) }
    var categoryDropdownExpanded by remember { mutableStateOf(false) }

    var customDetails by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(22.dp),
        containerColor = SurfaceWhite,
        title = {
            Column {
                Text(
                    text = if (type == "Complaint") "Report Garbage Issue" else "Request Bulk Pickup",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = CoastalNavy
                )
                Text(
                    text = "Fill out the location and concern details below",
                    fontSize = 12.sp,
                    color = TextSecondary
                )
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                ExposedDropdownMenuBox(
                    expanded = barangayDropdownExpanded,
                    onExpandedChange = { barangayDropdownExpanded = !barangayDropdownExpanded }
                ) {
                    OutlinedTextField(
                        value = selectedBarangay,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Barangay (Nasugbu)") },
                        trailingIcon = {
                            ExposedDropdownMenuDefaults.TrailingIcon(expanded = barangayDropdownExpanded)
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = barangayDropdownExpanded,
                        onDismissRequest = { barangayDropdownExpanded = false },
                        modifier = Modifier.heightIn(max = 220.dp)
                    ) {
                        for (brgy in barangays) {
                            DropdownMenuItem(
                                text = { Text(brgy, fontSize = 13.sp) },
                                onClick = {
                                    selectedBarangay = brgy
                                    barangayDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                ExposedDropdownMenuBox(
                    expanded = categoryDropdownExpanded,
                    onExpandedChange = { categoryDropdownExpanded = !categoryDropdownExpanded }
                ) {
                    OutlinedTextField(
                        value = selectedCategory,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text(if (type == "Complaint") "Issue Type" else "Waste Category") },
                        trailingIcon = {
                            ExposedDropdownMenuDefaults.TrailingIcon(expanded = categoryDropdownExpanded)
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = categoryDropdownExpanded,
                        onDismissRequest = { categoryDropdownExpanded = false }
                    ) {
                        for (category in categories) {
                            DropdownMenuItem(
                                text = { Text(category, fontSize = 13.sp) },
                                onClick = {
                                    selectedCategory = category
                                    categoryDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = customDetails,
                    onValueChange = { customDetails = it },
                    label = { Text("Specific Street / Landmark (Optional)") },
                    placeholder = { Text("e.g., Purok 3, near Brgy. Hall") },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val combinedDesc = if (customDetails.isNotBlank()) {
                        "$selectedCategory — ${customDetails.trim()}"
                    } else {
                        selectedCategory
                    }
                    onSubmit(selectedBarangay, combinedDesc)
                },
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (type == "Complaint") AlertRed else EcoGreen
                )
            ) {
                Text(
                    text = if (type == "Complaint") "Submit Report" else "Submit Request",
                    fontWeight = FontWeight.Bold
                )
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextSecondary)
            }
        }
    )
}

@Composable
private fun TicketStatusStepper(currentStatus: String) {
    val stages = listOf("Pending", "Processed", "Approved", "Completed")
    val normalizedStatus = if (currentStatus.startsWith("Rescheduled")) "Approved" else currentStatus
    var activeStep = stages.indexOf(normalizedStatus)
    if (activeStep < 0) activeStep = 0

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(BackgroundLight)
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            for (index in stages.indices) {
                val isReached = index <= activeStep
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(if (isReached) EcoGreen else BorderLight)
                )
                if (index < stages.size - 1) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(2.dp)
                            .background(if (index < activeStep) EcoGreen else BorderLight)
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(4.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            for (index in stages.indices) {
                val label = stages[index]
                Text(
                    text = if (label == "Completed") "Done" else label,
                    fontSize = 10.sp,
                    fontWeight = if (index == activeStep) FontWeight.Bold else FontWeight.Normal,
                    color = if (index <= activeStep) EcoGreen else TextSecondary
                )
            }
        }
    }
}