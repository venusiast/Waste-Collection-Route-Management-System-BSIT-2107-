package com.example.linisnasugbu.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.linisnasugbu.service.LinisNasugbuRepository

@Composable
fun BookingsScreen(
    role: String = "Resident",
    userName: String = "Juan Dela Cruz"
) {
    var modalType by remember { mutableStateOf<String?>(null) }
    var selectedFilter by remember { mutableStateOf("All") }
    val filters = listOf("All", "Pending", "Processed", "Approved", "Completed")

    val filteredTickets = LinisNasugbuRepository.tickets.filter {
        selectedFilter == "All" || it.status == selectedFilter
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundLight)
    ) {
        // Gradient Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp))
                .background(NasugbuHeroGradient)
                .padding(20.dp)
        ) {
            Column {
                Text(
                    text = if (role == "Manager") "Dispatch & Ticket Approvals" else "Requests & Reports",
                    color = SurfaceWhite,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = if (role == "Manager")
                        "Process & approve resident tickets for truck dispatch"
                    else
                        "Track your Pending, Processed, and Approved tickets",
                    color = SurfaceWhite.copy(alpha = 0.85f),
                    fontSize = 12.sp
                )
            }
        }

        Column(modifier = Modifier.padding(16.dp)) {
            // Action Buttons (Para sa Resident)
            if (role == "Resident") {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = { modalType = "Bulk Pickup" },
                        colors = ButtonDefaults.buttonColors(containerColor = EcoGreen),
                        modifier = Modifier.weight(1f).height(46.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Bulk Pickup", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { modalType = "Complaint" },
                        colors = ButtonDefaults.buttonColors(containerColor = SafetyOrange),
                        modifier = Modifier.weight(1f).height(46.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Report Issue", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Horizontal Scrollable Status Filter Chips (with live count)
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
            ) {
                filters.forEach { filter ->
                    val count = if (filter == "All") {
                        LinisNasugbuRepository.tickets.size
                    } else {
                        LinisNasugbuRepository.tickets.count { it.status == filter }
                    }
                    FilterChip(
                        selected = selectedFilter == filter,
                        onClick = { selectedFilter = filter },
                        label = { Text("$filter ($count)", fontSize = 11.sp) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(filteredTickets, key = { it.id }) { ticket ->
                    val (statusColor, statusBg) = when (ticket.status) {
                        "Completed" -> EcoGreen to MintAccent
                        "Approved" -> CoastalTeal to Color(0xFFE0F2F1)
                        "Processed" -> CoastalNavy to Color(0xFFE3F2FD)
                        else -> SafetyOrange to SoftOrangeBg // Pending
                    }

                    Card(
                        colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                        shape = RoundedCornerShape(16.dp),
                        elevation = CardDefaults.cardElevation(2.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "${ticket.id} • ${ticket.type}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = if (ticket.type == "Bulk Pickup") EcoGreen else AlertRed
                                )
                                Surface(shape = RoundedCornerShape(20.dp), color = statusBg) {
                                    Text(
                                        text = ticket.status.uppercase(),
                                        color = statusColor,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Text(ticket.barangay, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = TextPrimary)
                            Text("By: ${ticket.residentName}", fontSize = 12.sp, color = TextSecondary)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(ticket.description, fontSize = 13.sp, color = TextPrimary)

                            Spacer(modifier = Modifier.height(12.dp))

                            // Grab-Style 4-Stage Status Stepper (Pending -> Processed -> Approved -> Done)
                            TicketStatusStepper(currentStatus = ticket.status)

                            // Manager Workflow Actions: Pending -> Processed -> Approved
                            if (role == "Manager") {
                                when (ticket.status) {
                                    "Pending" -> {
                                        Spacer(modifier = Modifier.height(12.dp))
                                        Button(
                                            onClick = { LinisNasugbuRepository.processTicket(ticket.id) },
                                            colors = ButtonDefaults.buttonColors(containerColor = CoastalNavy),
                                            shape = RoundedCornerShape(10.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Mark as Processed (Verify)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                    "Processed" -> {
                                        Spacer(modifier = Modifier.height(12.dp))
                                        Button(
                                            onClick = { LinisNasugbuRepository.approveTicketAndAssign(ticket.id) },
                                            colors = ButtonDefaults.buttonColors(containerColor = EcoGreen),
                                            shape = RoundedCornerShape(10.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Approve & Dispatch to Collector", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (modalType != null) {
        RequestComplaintModal(
            type = modalType!!,
            onDismiss = { modalType = null },
            onSubmit = { brgy, desc ->
                LinisNasugbuRepository.submitTicket(userName, modalType!!, brgy, desc)
                modalType = null
            }
        )
    }
}

@Composable
private fun TicketStatusStepper(currentStatus: String) {
    val stages = listOf("Pending", "Processed", "Approved", "Completed")
    val activeStep = stages.indexOf(currentStatus).coerceAtLeast(0)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(BackgroundLight)
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            stages.forEachIndexed { index, _ ->
                val isReached = index <= activeStep
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(if (isReached) EcoGreen else BorderLight)
                )
                if (index < stages.lastIndex) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(2.dp)
                            .background(if (index < activeStep) EcoGreen else BorderLight)
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(4.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            stages.forEachIndexed { index, label ->
                Text(
                    text = if (label == "Completed") "Done" else label,
                    fontSize = 10.sp,
                    fontWeight = if (index == activeStep) FontWeight.Bold else FontWeight.Normal,
                    color = if (index <= activeStep) EcoGreen else TextSecondary
                )
            }
        }
    }
}