package com.example.linisnasugbu.model

import com.example.linisnasugbu.model.enums.UserRole

// Topic 10: Interface
interface Identifiable {
    val entityId: String
    fun getDisplayBadge(): String
}

// Topic 6 & 10: Abstraction & Abstract Class
abstract class User(
    override val entityId: String,
    open val name: String,
    private var _contactNumber: String, // Topic 5: Encapsulation
    open val email: String,
    open val role: UserRole
) : Identifiable {

    val userId: String get() = entityId

    var contactNumber: String
        get() = _contactNumber
        set(value) {
            if (value.isNotBlank()) _contactNumber = value
        }

    // Topic 9: Polymorphic abstract method
    abstract fun getDashboardSummary(): String

    open fun getFullInfo(): String {
        return "ID: $userId\nName: $name\nContact: $contactNumber\nRole: $role"
    }
}