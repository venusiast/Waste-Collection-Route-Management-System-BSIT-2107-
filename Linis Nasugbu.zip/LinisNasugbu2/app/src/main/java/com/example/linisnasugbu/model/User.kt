package com.example.linisnasugbu.model

import com.example.linisnasugbu.model.enums.UserRole

open class User(
    open val userId: String,
    open val name: String,
    open val contactNumber: String,
    open val email: String,
    open val role: UserRole
) {
    open fun getFullInfo(): String {
        return "ID: $userId\nName: $name\nContact: $contactNumber\nRole: $role"
    }
}
